using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Omur
{
    // Ana oyun ekranı: üst bar, istatistikler, sekmeler (Hayat, Eylemler, Hesap, Ayarlar) ve Yaşlan düğmesi.
    public sealed partial class OyunYoneticisi
    {
        private string sekme = "hayat";
        private string sonMesaj = "";
        private bool statGenis;

        private static readonly Color Mavi = new Color(0.35f, 0.66f, 0.90f, 1f);
        private static readonly Color Pembe = new Color(0.90f, 0.54f, 0.72f, 1f);
        private static readonly Color Mor = new Color(0.61f, 0.54f, 0.90f, 1f);
        private static readonly Color Turkuaz = new Color(0.36f, 0.76f, 0.71f, 1f);

        private void AnaEkran()
        {
            Goster(AnaEkranCiz);
        }

        private void AnaEkranCiz()
        {
            RectTransform govde = Ui.Nesne("Govde", ekran);
            Ui.Doldur(govde, 0, 0, 0, 0);
            Ui.Dikey(govde.gameObject, 12, 24, 16, 24, 16);

            UstBar(govde);
            StatPaneli(govde);

            RectTransform alan = Ui.Nesne("Alan", govde);
            Ui.Boyut(alan.gameObject, 300, -1, 1, -1, 1);
            switch (sekme)
            {
                case "eylem": SekmeEylemler(alan); break;
                case "hesap": SekmeHesap(alan); break;
                case "ayar": SekmeAyarlar(alan); break;
                default: SekmeHayat(alan); break;
            }

            YaslanDugmesi(govde);
            SekmeCubugu(govde);
        }

        // ------------------------------------------------------------------
        // Üst bar, istatistikler, alt bölge
        // ------------------------------------------------------------------

        private void UstBar(RectTransform ebeveyn)
        {
            RectTransform bar = Ui.Nesne("UstBar", ebeveyn);
            Image resim = bar.gameObject.AddComponent<Image>();
            resim.color = Tema.Panel;
            HorizontalLayoutGroup h = Ui.Yatay(bar.gameObject, 12, 28, 14, 28, 14);
            h.childForceExpandWidth = false;
            Ui.Yukseklik(bar.gameObject, 140, 140);

            RectTransform sol = Ui.Nesne("Sol", bar);
            Ui.Dikey(sol.gameObject, 2, 0, 0, 0, 0);
            Ui.Boyut(sol.gameObject, -1, -1, 1, -1, 1);
            Ui.Yaz(sol, hayat.TamAd, 44, Tema.Yazi, TextAnchor.MiddleLeft, FontStyle.Bold);
            Ui.Yaz(sol, hayat.Yas + " yaş  ·  " + hayat.Yil, 34, Tema.Soluk, TextAnchor.MiddleLeft, FontStyle.Normal);

            Text para = Ui.Yaz(bar, Tr.TL(hayat.Para), 40, Tema.Vurgu, TextAnchor.MiddleRight, FontStyle.Bold);
            Ui.Boyut(para.gameObject, -1, -1, -1, 380, 0);
        }

        private void StatPaneli(RectTransform ebeveyn)
        {
            RectTransform kart = Ui.Kart(ebeveyn, Tema.Panel, 20, 6);
            StatSatiri(kart, "Sağlık", hayat.Saglik, Tema.Iyi, "Mutluluk", hayat.Mutluluk, Tema.Vurgu);
            StatSatiri(kart, "Zekâ", hayat.Zeka, Mavi, "Görünüm", hayat.Gorunum, Pembe);
            if (statGenis)
            {
                StatSatiri(kart, "Sosyallik", hayat.Sosyallik, Mor, "Disiplin", hayat.Disiplin, Turkuaz);
                StatSatiri(kart, "İtibar", hayat.Itibar, Tema.Vurgu, "Stres", hayat.Stres, Tema.Kotu);
            }
            Ui.Dugme(kart, statGenis ? "Daha az" : "Daha fazla", Tema.PanelAcik, Tema.Soluk, () =>
            {
                statGenis = !statGenis;
                Yenile();
            }, 32, 64, null, true);
        }

        private void StatSatiri(RectTransform ebeveyn, string a, int av, Color ar, string b, int bv, Color br)
        {
            RectTransform satir = Ui.Nesne("StatSatir", ebeveyn);
            Ui.Yatay(satir.gameObject, 24, 0, 0, 0, 0);
            Ui.Yukseklik(satir.gameObject, 64, 64);
            Ui.StatCubugu(satir, a, av, ar);
            Ui.StatCubugu(satir, b, bv, br);
        }

        private void YaslanDugmesi(RectTransform ebeveyn)
        {
            string alt = "Şu an " + hayat.Yas + " yaşındasın";
            Ui.Dugme(ebeveyn, "Yaşlan", Tema.Vurgu, Tema.VurguYazi, () => YaslanTikla(), 58, 170, alt, true);
        }

        private void SekmeCubugu(RectTransform ebeveyn)
        {
            RectTransform satir = Ui.Nesne("Sekmeler", ebeveyn);
            Ui.Yatay(satir.gameObject, 10, 0, 0, 0, 0);
            Ui.Yukseklik(satir.gameObject, 120, 120);

            string[] idler = new string[] { "hayat", "eylem", "hesap", "ayar" };
            string[] adlar = new string[] { "Hayat", "Eylemler", "Hesap", "Ayarlar" };
            for (int i = 0; i < idler.Length; i++)
            {
                string id = idler[i];
                bool secili = sekme == id;
                Ui.Dugme(satir, adlar[i], secili ? Tema.Vurgu : Tema.PanelAcik, secili ? Tema.VurguYazi : Tema.Yazi, () =>
                {
                    sekme = id;
                    Yenile();
                }, 32, 120, null, true);
            }
        }

        // ------------------------------------------------------------------
        // Sekmeler
        // ------------------------------------------------------------------

        private void SekmeHayat(RectTransform alan)
        {
            ScrollRect sr;
            RectTransform ic = Ui.Kaydirma(alan, 8, 10, out sr);
            GunlukBas(ic);
            StartCoroutine(AltaKaydir(sr));
        }

        private System.Collections.IEnumerator AltaKaydir(ScrollRect sr)
        {
            yield return null;
            Canvas.ForceUpdateCanvases();
            if (sr != null) sr.verticalNormalizedPosition = 0f;
        }

        /// <summary>Hayat günlüğünü verilen içerik alanına yıl yıl yazar (yeni satırlar altta).</summary>
        private void GunlukBas(RectTransform ic)
        {
            if (hayat.GunlukKirpildi)
            {
                Ui.Yaz(ic, "Önceki yıllar özetlendi.", 34, Tema.Soluk, TextAnchor.UpperCenter, FontStyle.Italic);
            }
            int sonYas = -1;
            for (int i = 0; i < hayat.Gunluk.Count; i++)
            {
                GunlukSatiri satir = hayat.Gunluk[i];
                if (satir.Yas != sonYas)
                {
                    sonYas = satir.Yas;
                    Ui.Bosluk(ic, 10);
                    Ui.Yaz(ic, satir.Yas + " yaş  ·  " + (hayat.DogumYili + satir.Yas), 36, Tema.Vurgu, TextAnchor.UpperLeft, FontStyle.Bold);
                }
                Ui.Yaz(ic, satir.Metin, 42, Tema.Yazi);
            }
            Ui.Bosluk(ic, 10);
        }

        private void SekmeEylemler(RectTransform alan)
        {
            ScrollRect sr;
            RectTransform ic = Ui.Kaydirma(alan, 8, 14, out sr);

            if (hayat.Yas < 6)
            {
                RectTransform kart = Ui.Kart(ic, Tema.Panel, 32, 12);
                Ui.Yaz(kart, "Henüz çok küçüksün.", 44, Tema.Yazi, TextAnchor.UpperLeft, FontStyle.Bold);
                Ui.Yaz(kart, "Eylemler 6 yaşından sonra açılır. O zamana kadar hayat kendiliğinden akar; sen yalnızca Yaşlan düğmesine bas.", 40, Tema.Soluk);
                return;
            }

            Ui.Yaz(ic, "Bu yıl kalan eylem hakkın: " + hayat.KalanEylem, 44, Tema.Vurgu, TextAnchor.UpperLeft, FontStyle.Bold);
            if (!string.IsNullOrEmpty(sonMesaj))
            {
                RectTransform mesaj = Ui.Kart(ic, Tema.PanelAcik, 24, 6);
                Ui.Yaz(mesaj, sonMesaj, 38, Tema.Yazi);
            }

            List<Eylem> eylemler = motor.UygunEylemler();
            for (int i = 0; i < eylemler.Count; i++)
            {
                Eylem e = eylemler[i];
                string neden;
                bool etkin = motor.EylemYapilabilir(e, out neden);
                string alt = e.Aciklama;
                if (e.Sans != null) alt += "  Şans: " + SansMetni(SansMotoru.Yuzde(hayat, e.Sans, 0));
                long ucret = motor.EylemUcreti(e);
                if (ucret > 0) alt += "  Ücret: " + Tr.TL(ucret);
                if (!etkin) alt = neden;
                Ui.Dugme(ic, e.Ad, Tema.PanelAcik, Tema.Yazi, () => EylemTikla(e), 42, 130, alt, etkin);
            }
        }

        private void EylemTikla(Eylem e)
        {
            SecimSonucu s = motor.EylemYap(e.Id);
            if (!s.Yapildi)
            {
                sonMesaj = s.Metin;
            }
            else
            {
                string durum = "";
                if (s.SansVar) durum = s.Basari ? "  (Başarılı)" : "  (Zorlandın)";
                sonMesaj = e.Ad + durum + ": " + s.Metin;
                if (s.EtkiOzeti.Length > 0) sonMesaj += "\n" + s.EtkiOzeti;
            }
            KaydetYuva(false);
            if (!hayat.Yasiyor)
            {
                KaydetYuva(true);
                OlumEkrani();
                return;
            }
            Yenile();
        }

        private void SekmeHesap(RectTransform alan)
        {
            ScrollRect sr;
            RectTransform ic = Ui.Kaydirma(alan, 8, 14, out sr);

            RectTransform kimlik = Ui.Kart(ic, Tema.Panel, 28, 6);
            Ui.IkiliSatir(kimlik, "Para", Tr.TL(hayat.Para), Tema.Vurgu);
            Ui.IkiliSatir(kimlik, "Doğum yeri", hayat.Il, Tema.Yazi);
            Ui.IkiliSatir(kimlik, "Anne", hayat.AnneAdi + " (" + hayat.AnneMeslek + ")", Tema.Yazi);
            Ui.IkiliSatir(kimlik, "Baba", hayat.BabaAdi + " (" + hayat.BabaMeslek + ")", Tema.Yazi);
            Ui.IkiliSatir(kimlik, "Kardeş", hayat.KardesSayisi.ToString(), Tema.Yazi);
            string[] duzeyler = new string[] { "Düşük gelirli", "Orta gelirli", "Yüksek gelirli" };
            Ui.IkiliSatir(kimlik, "Aile", duzeyler[Mathf.Clamp(hayat.AileDuzeyi, 0, 2)], Tema.Yazi);

            RectTransform stat = Ui.Kart(ic, Tema.Panel, 28, 6);
            Ui.Yaz(stat, "Tüm özellikler", 38, Tema.Soluk, TextAnchor.UpperLeft, FontStyle.Bold);
            Ui.IkiliSatir(stat, "Sağlık", hayat.Saglik.ToString(), Tema.Yazi);
            Ui.IkiliSatir(stat, "Mutluluk", hayat.Mutluluk.ToString(), Tema.Yazi);
            Ui.IkiliSatir(stat, "Zekâ", hayat.Zeka.ToString(), Tema.Yazi);
            Ui.IkiliSatir(stat, "Görünüm", hayat.Gorunum.ToString(), Tema.Yazi);
            Ui.IkiliSatir(stat, "Sosyallik", hayat.Sosyallik.ToString(), Tema.Yazi);
            Ui.IkiliSatir(stat, "Disiplin", hayat.Disiplin.ToString(), Tema.Yazi);
            Ui.IkiliSatir(stat, "İtibar", hayat.Itibar.ToString(), Tema.Yazi);
            Ui.IkiliSatir(stat, "Stres", hayat.Stres.ToString(), Tema.Yazi);
            Ui.IkiliSatir(stat, "Hayat puanı", OyunMotoru.HayatPuani(hayat).ToString(), Tema.Vurgu);

            RectTransform not = Ui.Kart(ic, Tema.PanelAcik, 28, 6);
            Ui.Yaz(not, "Mal varlığı, borç, gelir ve gider kalemleri meslekler ve ekonomi eklendiğinde (3. faz) burada görünecek.", 36, Tema.Soluk);
        }

        private void SekmeAyarlar(RectTransform alan)
        {
            ScrollRect sr;
            RectTransform ic = Ui.Kaydirma(alan, 8, 14, out sr);
            AyarlariCiz(ic, true);
        }

        private string SansMetni(int yuzde)
        {
            return Tema.SansYuzdeGoster ? "%" + yuzde : SansMotoru.Etiket(yuzde);
        }

        // ------------------------------------------------------------------
        // Yıl akışı: Yaşlan → olaylar → yıl sonu raporu
        // ------------------------------------------------------------------

        private void YaslanTikla()
        {
            if (!hayat.Yasiyor)
            {
                OlumEkrani();
                return;
            }
            YilRaporu rapor = motor.YilBaslat();
            if (rapor.Oldu)
            {
                KaydetYuva(true);
                OlumEkrani();
                return;
            }
            SiradakiOlay();
        }

        private void SiradakiOlay()
        {
            Olay o = motor.SonrakiSecimliOlay();
            if (!hayat.Yasiyor)
            {
                KaydetYuva(true);
                OlumEkrani();
                return;
            }
            if (o == null)
            {
                YilSonu();
                return;
            }
            OlayGoster(o);
        }

        private void OlayGoster(Olay o)
        {
            RectTransform kart = ModalKart();
            Ui.Yaz(kart, hayat.Yas + " yaşında  ·  " + HavuzAdi.Ad(o.Havuz), 34, Tema.Vurgu, TextAnchor.UpperLeft, FontStyle.Bold);
            Ui.Yaz(kart, motor.GecerliMetin, 44, Tema.Yazi);
            Ui.Bosluk(kart, 4);

            for (int i = 0; i < o.Secenekler.Count; i++)
            {
                Secenek s = o.Secenekler[i];
                int sira = i;
                bool etkin = motor.SecenekKullanilabilir(s);
                string alt = SecenekAltMetni(s, etkin);
                Ui.Dugme(kart, s.Etiket, Tema.PanelAcik, Tema.Yazi, () => SecimYap(sira), 42, 120, alt, etkin);
            }
        }

        private string SecenekAltMetni(Secenek s, bool etkin)
        {
            List<string> parcalar = new List<string>();
            if (s.Sans != null) parcalar.Add("Şans: " + SansMetni(SansMotoru.Yuzde(hayat, s.Sans, 0)));
            if (s.Ucret > 0) parcalar.Add("Ücret: " + Tr.TL(s.Ucret));
            if (!etkin) parcalar.Add("şu an kullanılamaz");
            return string.Join("  ·  ", parcalar.ToArray());
        }

        private void SecimYap(int sira)
        {
            SecimSonucu r = motor.Sec(sira);
            if (!r.Yapildi) return;
            SonucGoster(r);
        }

        private void SonucGoster(SecimSonucu r)
        {
            RectTransform kart = ModalKart();
            string baslik = "Sonuç";
            Color renk = Tema.Vurgu;
            if (r.SansVar)
            {
                if (r.Kritik) baslik = r.Basari ? "Kritik başarı!" : "Kritik başarısızlık!";
                else baslik = r.Basari ? "Başarılı" : "Olmadı";
                baslik += "  (Şans: " + SansMetni(r.Yuzde) + ")";
                renk = r.Basari ? Tema.Iyi : Tema.Kotu;
            }
            Ui.Yaz(kart, baslik, 46, renk, TextAnchor.MiddleCenter, FontStyle.Bold);
            Ui.Yaz(kart, r.Metin, 44, Tema.Yazi);
            if (r.EtkiOzeti.Length > 0) Ui.Yaz(kart, r.EtkiOzeti, 36, Tema.Soluk);
            Ui.Dugme(kart, "Devam", Tema.Vurgu, Tema.VurguYazi, () => SiradakiOlay());
        }

        private void YilSonu()
        {
            YilRaporu rap = motor.YilBitir();
            KaydetYuva(false);
            sonMesaj = "";

            RectTransform kart = ModalKart();
            Ui.Yaz(kart, rap.Yas + " yaşını tamamladın", 48, Tema.Vurgu, TextAnchor.MiddleCenter, FontStyle.Bold);
            Ui.Yaz(kart, "Yeni yaşın: " + hayat.Yas + "  ·  " + hayat.Yil, 38, Tema.Soluk, TextAnchor.MiddleCenter, FontStyle.Normal);

            for (int i = 0; i < rap.Satirlar.Count && i < 5; i++)
            {
                Ui.Yaz(kart, rap.Satirlar[i], 38, Tema.Yazi);
            }

            bool degisim = false;
            for (int i = 0; i < IstatBilgi.Adet; i++)
            {
                Istat istat = (Istat)i;
                if (istat == Istat.Sans || istat == Istat.Arananlik) continue;
                int fark = rap.StatFarki[i];
                if (fark == 0) continue;
                degisim = true;
                bool iyi = istat == Istat.Stres ? fark < 0 : fark > 0;
                Ui.IkiliSatir(kart, IstatBilgi.GorunenAd(istat), (fark > 0 ? "+" : "") + fark, iyi ? Tema.Iyi : Tema.Kotu);
            }
            if (rap.ParaFarki != 0)
            {
                degisim = true;
                Ui.IkiliSatir(kart, "Para", (rap.ParaFarki > 0 ? "+" : "-") + Tr.TL(Math.Abs(rap.ParaFarki)), rap.ParaFarki > 0 ? Tema.Iyi : Tema.Kotu);
            }
            if (!degisim)
            {
                Ui.Yaz(kart, "Bu yıl özelliklerinde belirgin bir değişim olmadı.", 36, Tema.Soluk);
            }

            Ui.Dugme(kart, "Devam", Tema.Vurgu, Tema.VurguYazi, () =>
            {
                ModalKapat();
                Yenile();
            });
        }

        // ------------------------------------------------------------------
        // Ölüm
        // ------------------------------------------------------------------

        private void OlumEkrani()
        {
            Goster(OlumCiz);
        }

        private void OlumCiz()
        {
            RectTransform ic = Sayfa();
            Ui.Bosluk(ic, 60);
            Ui.Yaz(ic, "Hayatın sona erdi", 76, Tema.Kotu, TextAnchor.UpperCenter, FontStyle.Bold);
            Ui.Yaz(ic, hayat.TamAd, 56, Tema.Yazi, TextAnchor.UpperCenter, FontStyle.Bold);
            Ui.Yaz(ic, hayat.OlumYasi + " yaşında", 44, Tema.Soluk, TextAnchor.UpperCenter, FontStyle.Normal);

            RectTransform kart = Ui.Kart(ic, Tema.Panel, 36, 18);
            List<string> ozet = motor.OlumOzeti();
            for (int i = 0; i < ozet.Count; i++) Ui.Yaz(kart, ozet[i], 40, Tema.Yazi);

            Ui.Dugme(ic, "Hayat günlüğünü oku", Tema.PanelAcik, Tema.Yazi, () => GunlukModal());
            Ui.Dugme(ic, "Yeni hayat", Tema.Vurgu, Tema.VurguYazi, () => KarakterOlustur(aktifYuva));
            Ui.Dugme(ic, "Ana menü", Tema.PanelAcik, Tema.Soluk, () => AnaMenu());
        }

        private void GunlukModal()
        {
            RectTransform liste = ModalListe("Hayat günlüğü", "Kapat");
            GunlukBas(liste);
        }
    }
}
