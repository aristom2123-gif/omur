using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Omur
{
    /// <summary>
    /// Sahne düzenlemesi gerektirmeyen, kodla arayüz kuran yardımcılar (UGUI).
    /// Her metin supportRichText=false ile basılır; oyuncunun yazdığı metin işaretleme olarak yorumlanmaz.
    /// </summary>
    public static class Ui
    {
        private static Font yaziTipi;

        public static Font YaziTipi
        {
            get
            {
                if (yaziTipi == null)
                {
#if UNITY_2022_2_OR_NEWER
                    yaziTipi = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
                    yaziTipi = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
                    if (yaziTipi == null)
                    {
                        yaziTipi = Font.CreateDynamicFontFromOSFont(new string[] { "Arial", "Roboto", "Helvetica" }, 32);
                    }
                }
                return yaziTipi;
            }
        }

        // ------------------------------------------------------------------
        // Temel nesneler ve yerleşim
        // ------------------------------------------------------------------

        public static RectTransform Nesne(string ad, Transform ebeveyn)
        {
            GameObject go = new GameObject(ad, typeof(RectTransform));
            go.transform.SetParent(ebeveyn, false);
            return (RectTransform)go.transform;
        }

        /// <summary>Ebeveynin tamamını kaplar; kenar boşlukları pikseldir.</summary>
        public static void Doldur(RectTransform rt, float sol, float alt, float sag, float ust)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.offsetMin = new Vector2(sol, alt);
            rt.offsetMax = new Vector2(-sag, -ust);
        }

        /// <summary>Oransal çapa; kenar boşluğu yok.</summary>
        public static void Capa(RectTransform rt, float xMin, float yMin, float xMax, float yMax)
        {
            rt.anchorMin = new Vector2(xMin, yMin);
            rt.anchorMax = new Vector2(xMax, yMax);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        public static Image Zemin(Transform ebeveyn, string ad, Color renk)
        {
            RectTransform rt = Nesne(ad, ebeveyn);
            Image img = rt.gameObject.AddComponent<Image>();
            img.color = renk;
            return img;
        }

        public static VerticalLayoutGroup Dikey(GameObject go, float bosluk, int sol, int ust, int sag, int alt)
        {
            VerticalLayoutGroup v = go.AddComponent<VerticalLayoutGroup>();
            v.spacing = bosluk;
            v.padding = new RectOffset(sol, sag, ust, alt);
            v.childAlignment = TextAnchor.UpperCenter;
            v.childControlWidth = true;
            v.childControlHeight = true;
            v.childForceExpandWidth = true;
            v.childForceExpandHeight = false;
            return v;
        }

        public static HorizontalLayoutGroup Yatay(GameObject go, float bosluk, int sol, int ust, int sag, int alt)
        {
            HorizontalLayoutGroup h = go.AddComponent<HorizontalLayoutGroup>();
            h.spacing = bosluk;
            h.padding = new RectOffset(sol, sag, ust, alt);
            h.childAlignment = TextAnchor.MiddleCenter;
            h.childControlWidth = true;
            h.childControlHeight = true;
            h.childForceExpandWidth = true;
            h.childForceExpandHeight = true;
            return h;
        }

        /// <summary>Düzen içindeki boyut ipuçları. -1 verilen değer kullanılmaz.</summary>
        public static LayoutElement Boyut(GameObject go, float enAzYuk, float tercihYuk, float esnekYuk, float tercihGen, float esnekGen)
        {
            LayoutElement le = go.GetComponent<LayoutElement>();
            if (le == null) le = go.AddComponent<LayoutElement>();
            le.minHeight = enAzYuk;
            le.preferredHeight = tercihYuk;
            le.flexibleHeight = esnekYuk;
            le.preferredWidth = tercihGen;
            le.flexibleWidth = esnekGen;
            return le;
        }

        public static LayoutElement Yukseklik(GameObject go, float enAz, float tercih)
        {
            return Boyut(go, enAz, tercih, -1, -1, -1);
        }

        public static void Bosluk(Transform ebeveyn, float yukseklik)
        {
            RectTransform rt = Nesne("Bosluk", ebeveyn);
            Yukseklik(rt.gameObject, yukseklik, yukseklik);
        }

        // ------------------------------------------------------------------
        // Metin, kart, düğme
        // ------------------------------------------------------------------

        public static Text Yaz(Transform ebeveyn, string metin, int boyut, Color renk, TextAnchor hiza, FontStyle stil)
        {
            RectTransform rt = Nesne("Yazi", ebeveyn);
            Text t = rt.gameObject.AddComponent<Text>();
            t.font = YaziTipi;
            t.text = metin;
            t.fontSize = Mathf.RoundToInt(boyut * Tema.YaziOlcek);
            t.color = renk;
            t.alignment = hiza;
            t.fontStyle = stil;
            t.supportRichText = false;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            return t;
        }

        public static Text Yaz(Transform ebeveyn, string metin, int boyut, Color renk)
        {
            return Yaz(ebeveyn, metin, boyut, renk, TextAnchor.UpperLeft, FontStyle.Normal);
        }

        /// <summary>İçeriği dikey dizilen, arka planlı kart.</summary>
        public static RectTransform Kart(Transform ebeveyn, Color renk, int kenar, float bosluk)
        {
            RectTransform rt = Nesne("Kart", ebeveyn);
            Image img = rt.gameObject.AddComponent<Image>();
            img.color = renk;
            Dikey(rt.gameObject, bosluk, kenar, kenar, kenar, kenar);
            return rt;
        }

        /// <summary>Büyük dokunma alanlı düğme. alt: ikinci satırda küçük açıklama. etkin=false ise tıklanamaz.</summary>
        public static Button Dugme(Transform ebeveyn, string metin, Color zemin, Color yazi, UnityAction tikla,
            int boyut, float enAzYuk, string alt, bool etkin)
        {
            RectTransform rt = Nesne("Dugme", ebeveyn);
            Image img = rt.gameObject.AddComponent<Image>();
            img.color = zemin;

            Button b = rt.gameObject.AddComponent<Button>();
            b.targetGraphic = img;
            ColorBlock cb = b.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(0.94f, 0.94f, 0.94f, 1f);
            cb.pressedColor = new Color(0.76f, 0.76f, 0.76f, 1f);
            cb.selectedColor = Color.white;
            cb.disabledColor = new Color(0.6f, 0.6f, 0.6f, 0.65f);
            cb.colorMultiplier = 1f;
            cb.fadeDuration = 0.08f;
            b.colors = cb;

            VerticalLayoutGroup v = Dikey(rt.gameObject, 6, 26, 20, 26, 20);
            v.childAlignment = TextAnchor.MiddleCenter;
            Yukseklik(rt.gameObject, enAzYuk, -1);

            Color yaziRenk = etkin ? yazi : Tema.Soluk;
            Yaz(rt, metin, boyut, yaziRenk, TextAnchor.MiddleCenter, FontStyle.Bold);
            if (!string.IsNullOrEmpty(alt))
            {
                Color altRenk = new Color(yaziRenk.r, yaziRenk.g, yaziRenk.b, 0.8f);
                Yaz(rt, alt, Mathf.RoundToInt(boyut * 0.72f), altRenk, TextAnchor.MiddleCenter, FontStyle.Normal);
            }

            if (tikla != null && etkin) b.onClick.AddListener(tikla);
            b.interactable = etkin;
            return b;
        }

        public static Button Dugme(Transform ebeveyn, string metin, Color zemin, Color yazi, UnityAction tikla)
        {
            return Dugme(ebeveyn, metin, zemin, yazi, tikla, 44, 130, null, true);
        }

        /// <summary>İki sütunlu satır: solda ad, sağda değer.</summary>
        public static void IkiliSatir(Transform ebeveyn, string sol, string sag, Color sagRenk)
        {
            RectTransform satir = Nesne("Satir", ebeveyn);
            Yatay(satir.gameObject, 12, 0, 4, 0, 4);
            Yukseklik(satir.gameObject, 56, -1);
            Text a = Yaz(satir, sol, 40, Tema.Yazi, TextAnchor.MiddleLeft, FontStyle.Normal);
            Boyut(a.gameObject, -1, -1, 1, -1, 1);
            Text b = Yaz(satir, sag, 40, sagRenk, TextAnchor.MiddleRight, FontStyle.Bold);
            Boyut(b.gameObject, -1, -1, 1, -1, 1);
        }

        public static InputField Girdi(Transform ebeveyn, string yerTutucu, int karakterSiniri)
        {
            RectTransform rt = Nesne("Girdi", ebeveyn);
            Image img = rt.gameObject.AddComponent<Image>();
            img.color = Tema.PanelAcik;
            InputField f = rt.gameObject.AddComponent<InputField>();
            Yukseklik(rt.gameObject, 130, 130);

            RectTransform metinRt = Nesne("Metin", rt);
            Doldur(metinRt, 26, 10, 26, 10);
            Text t = metinRt.gameObject.AddComponent<Text>();
            t.font = YaziTipi;
            t.fontSize = Mathf.RoundToInt(46 * Tema.YaziOlcek);
            t.color = Tema.Yazi;
            t.alignment = TextAnchor.MiddleLeft;
            t.supportRichText = false;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Truncate;
            t.raycastTarget = false;

            RectTransform yerRt = Nesne("YerTutucu", rt);
            Doldur(yerRt, 26, 10, 26, 10);
            Text p = yerRt.gameObject.AddComponent<Text>();
            p.font = YaziTipi;
            p.fontSize = Mathf.RoundToInt(46 * Tema.YaziOlcek);
            p.fontStyle = FontStyle.Italic;
            p.color = Tema.Soluk;
            p.alignment = TextAnchor.MiddleLeft;
            p.supportRichText = false;
            p.text = yerTutucu;
            p.raycastTarget = false;

            f.targetGraphic = img;
            f.textComponent = t;
            f.placeholder = p;
            f.characterLimit = karakterSiniri;
            f.lineType = InputField.LineType.SingleLine;
            return f;
        }

        // ------------------------------------------------------------------
        // Kaydırma alanı
        // ------------------------------------------------------------------

        /// <summary>Dikey kaydırılan alan kurar; içerik dikey düzenlidir. İçerik nesnesini döner.</summary>
        public static RectTransform Kaydirma(Transform ebeveyn, int kenar, float bosluk, out ScrollRect sr)
        {
            RectTransform kok = Nesne("Kaydirma", ebeveyn);
            Doldur(kok, 0, 0, 0, 0);
            Image bg = kok.gameObject.AddComponent<Image>();
            bg.color = new Color(0f, 0f, 0f, 0f);
            sr = kok.gameObject.AddComponent<ScrollRect>();

            RectTransform gorunum = Nesne("Gorunum", kok);
            Doldur(gorunum, 0, 0, 0, 0);
            gorunum.gameObject.AddComponent<RectMask2D>();

            RectTransform icerik = Nesne("Icerik", gorunum);
            icerik.anchorMin = new Vector2(0f, 1f);
            icerik.anchorMax = new Vector2(1f, 1f);
            icerik.pivot = new Vector2(0.5f, 1f);
            icerik.anchoredPosition = Vector2.zero;
            icerik.sizeDelta = Vector2.zero;
            Dikey(icerik.gameObject, bosluk, kenar, kenar, kenar, kenar);
            ContentSizeFitter fit = icerik.gameObject.AddComponent<ContentSizeFitter>();
            fit.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            fit.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;

            sr.content = icerik;
            sr.viewport = gorunum;
            sr.horizontal = false;
            sr.vertical = true;
            sr.movementType = ScrollRect.MovementType.Elastic;
            sr.scrollSensitivity = 40f;
            sr.decelerationRate = 0.135f;
            return icerik;
        }

        // ------------------------------------------------------------------
        // İstatistik çubuğu
        // ------------------------------------------------------------------

        public static void StatCubugu(Transform ebeveyn, string ad, int deger, Color dolgu)
        {
            RectTransform kok = Nesne("Stat", ebeveyn);
            Boyut(kok.gameObject, 64, 64, -1, -1, 1);

            Text etiket = Yaz(kok, ad, 32, Tema.Yazi, TextAnchor.MiddleLeft, FontStyle.Normal);
            etiket.horizontalOverflow = HorizontalWrapMode.Overflow;
            Capa(etiket.rectTransform, 0f, 0f, 0.38f, 1f);

            RectTransform bar = Nesne("Bar", kok);
            Capa(bar, 0.39f, 0.3f, 0.84f, 0.7f);
            Image bg = bar.gameObject.AddComponent<Image>();
            bg.color = Tema.PanelAcik;

            RectTransform dolguRt = Nesne("Dolgu", bar);
            Capa(dolguRt, 0f, 0f, Mathf.Clamp01(deger / 100f), 1f);
            Image di = dolguRt.gameObject.AddComponent<Image>();
            di.color = dolgu;

            Text sayi = Yaz(kok, deger.ToString(), 32, Tema.Yazi, TextAnchor.MiddleRight, FontStyle.Bold);
            Capa(sayi.rectTransform, 0.86f, 0f, 1f, 1f);
        }
    }
}
