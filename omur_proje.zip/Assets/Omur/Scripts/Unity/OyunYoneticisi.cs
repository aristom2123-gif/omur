using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Omur
{
    /// <summary>
    /// Oyunun tek MonoBehaviour'u: tuvali kurar, ekranlar arasında geçişi ve oyun akışını yönetir.
    /// Ekranlar OyunYoneticisi.*.cs dosyalarında (partial) ayrılmıştır.
    /// </summary>
    public sealed partial class OyunYoneticisi : MonoBehaviour
    {
        public static OyunYoneticisi Ornek { get; private set; }

        private Canvas tuval;
        private Image zeminResmi;
        private RectTransform guvenli;
        private RectTransform ekran;
        private RectTransform modalKatman;
        private Action suankiEkran;

        private int aktifYuva = -1;
        private Hayat hayat;
        private OyunMotoru motor;

        private Rect sonGuvenliAlan;
        private int sonGenislik;
        private int sonYukseklik;

        private void Awake()
        {
            if (Ornek != null && Ornek != this)
            {
                Destroy(gameObject);
                return;
            }
            Ornek = this;

            Tema.Yukle();
            Kur();

            System.Collections.Generic.List<string> sorunlar = OlayHavuzu.Dogrula();
            if (sorunlar.Count > 0)
            {
                for (int i = 0; i < sorunlar.Count; i++) Debug.LogWarning("[Ömür veri] " + sorunlar[i]);
            }

            IlkEkran();
        }

        private void Update()
        {
            if (guvenli == null) return;
            if (sonGuvenliAlan != Screen.safeArea || sonGenislik != Screen.width || sonYukseklik != Screen.height)
            {
                GuvenliAlaniUygula();
            }
        }

        // ------------------------------------------------------------------
        // Kurulum
        // ------------------------------------------------------------------

        private void Kur()
        {
            Application.targetFrameRate = 60;
#if UNITY_ANDROID || UNITY_IOS
            Screen.orientation = ScreenOrientation.Portrait;
#endif
            KameraGaranti();
            EventSystemGaranti();

            GameObject tuvalGo = new GameObject("Tuval", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            tuvalGo.transform.SetParent(transform, false);

            tuval = tuvalGo.GetComponent<Canvas>();
            tuval.renderMode = RenderMode.ScreenSpaceOverlay;
            tuval.sortingOrder = 10;

            CanvasScaler olcek = tuvalGo.GetComponent<CanvasScaler>();
            olcek.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            olcek.referenceResolution = new Vector2(1080f, 1920f);
            olcek.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            olcek.matchWidthOrHeight = 0.5f;

            zeminResmi = Ui.Zemin(tuvalGo.transform, "Zemin", Tema.Zemin);
            Ui.Doldur(zeminResmi.rectTransform, 0, 0, 0, 0);

            guvenli = Ui.Nesne("GuvenliAlan", tuvalGo.transform);
            ekran = Ui.Nesne("Ekran", guvenli);
            Ui.Doldur(ekran, 0, 0, 0, 0);

            modalKatman = Ui.Nesne("Modal", tuvalGo.transform);
            Ui.Doldur(modalKatman, 0, 0, 0, 0);

            GuvenliAlaniUygula();
        }

        private void GuvenliAlaniUygula()
        {
            Rect sa = Screen.safeArea;
            sonGuvenliAlan = sa;
            sonGenislik = Screen.width;
            sonYukseklik = Screen.height;
            if (Screen.width <= 0 || Screen.height <= 0) return;

            Vector2 enAz = sa.position;
            Vector2 enCok = sa.position + sa.size;
            guvenli.anchorMin = new Vector2(enAz.x / Screen.width, enAz.y / Screen.height);
            guvenli.anchorMax = new Vector2(enCok.x / Screen.width, enCok.y / Screen.height);
            guvenli.offsetMin = Vector2.zero;
            guvenli.offsetMax = Vector2.zero;
        }

        private void KameraGaranti()
        {
            if (Camera.allCamerasCount > 0) return;
            GameObject go = new GameObject("OmurKamera", typeof(Camera));
            go.transform.SetParent(transform, false);
            Camera kamera = go.GetComponent<Camera>();
            kamera.clearFlags = CameraClearFlags.SolidColor;
            kamera.backgroundColor = Tema.Zemin;
            kamera.orthographic = true;
        }

        private void EventSystemGaranti()
        {
            if (EventSystem.current != null) return;
            GameObject go = new GameObject("EventSystem", typeof(EventSystem));
            go.transform.SetParent(transform, false);
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
            UnityEngine.InputSystem.UI.InputSystemUIInputModule modul = go.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
            modul.AssignDefaultActions();
#else
            go.AddComponent<StandaloneInputModule>();
#endif
        }

        // ------------------------------------------------------------------
        // Ekran yönetimi
        // ------------------------------------------------------------------

        private static void Temizle(RectTransform rt)
        {
            for (int i = rt.childCount - 1; i >= 0; i--)
            {
                Transform cocuk = rt.GetChild(i);
                cocuk.SetParent(null, false);
                Destroy(cocuk.gameObject);
            }
        }

        /// <summary>Verilen çizim işlevini ekrana basar; tema/yazı değişince Yenile() aynı ekranı yeniden çizer.</summary>
        private void Goster(Action ciz)
        {
            suankiEkran = ciz;
            ModalKapat();
            Temizle(ekran);
            zeminResmi.color = Tema.Zemin;
            ciz();
        }

        private void Yenile()
        {
            if (suankiEkran != null) Goster(suankiEkran);
        }

        private void ModalKapat()
        {
            Temizle(modalKatman);
        }

        /// <summary>Ortada, içeriğe göre boyutlanan bir kart açar. İçine Ui.Yaz / Ui.Dugme ile eklenir.</summary>
        private RectTransform ModalKart()
        {
            ModalKapat();
            RectTransform dim = Ui.Nesne("Dim", modalKatman);
            Ui.Doldur(dim, 0, 0, 0, 0);
            Image dimResmi = dim.gameObject.AddComponent<Image>();
            dimResmi.color = Tema.Dim;

            RectTransform kart = Ui.Nesne("Kart", dim);
            kart.anchorMin = new Vector2(0.05f, 0.5f);
            kart.anchorMax = new Vector2(0.95f, 0.5f);
            kart.pivot = new Vector2(0.5f, 0.5f);
            kart.anchoredPosition = Vector2.zero;
            kart.sizeDelta = Vector2.zero;
            Image kartResmi = kart.gameObject.AddComponent<Image>();
            kartResmi.color = Tema.Panel;
            Ui.Dikey(kart.gameObject, 18, 40, 40, 40, 40);
            ContentSizeFitter uyum = kart.gameObject.AddComponent<ContentSizeFitter>();
            uyum.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            uyum.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            return kart;
        }

        /// <summary>Uzun listeler için: yükseklikçe büyük, içeriği kaydırılan modal. İçerik nesnesini döner.</summary>
        private RectTransform ModalListe(string baslik, string kapatEtiketi)
        {
            ModalKapat();
            RectTransform dim = Ui.Nesne("Dim", modalKatman);
            Ui.Doldur(dim, 0, 0, 0, 0);
            Image dimResmi = dim.gameObject.AddComponent<Image>();
            dimResmi.color = Tema.Dim;

            RectTransform kart = Ui.Nesne("Kart", dim);
            Ui.Capa(kart, 0.05f, 0.06f, 0.95f, 0.94f);
            Image kartResmi = kart.gameObject.AddComponent<Image>();
            kartResmi.color = Tema.Panel;
            Ui.Dikey(kart.gameObject, 16, 32, 32, 32, 32);

            Ui.Yaz(kart, baslik, 50, Tema.Vurgu, TextAnchor.MiddleCenter, FontStyle.Bold);

            ScrollRect sr;
            RectTransform icerik = Ui.Kaydirma(kart, 4, 12, out sr);
            Ui.Boyut(sr.gameObject, 200, -1, 1, -1, 1);

            Ui.Dugme(kart, kapatEtiketi, Tema.PanelAcik, Tema.Yazi, () => ModalKapat());
            return icerik;
        }

        /// <summary>Tek düğmeli bilgi penceresi.</summary>
        private void Bilgi(string baslik, string metin)
        {
            RectTransform kart = ModalKart();
            Ui.Yaz(kart, baslik, 50, Tema.Vurgu, TextAnchor.MiddleCenter, FontStyle.Bold);
            Ui.Yaz(kart, metin, 42, Tema.Yazi);
            Ui.Dugme(kart, "Tamam", Tema.Vurgu, Tema.VurguYazi, () => ModalKapat());
        }

        /// <summary>Evet / Vazgeç onayı.</summary>
        private void Onay(string baslik, string metin, string evetEtiketi, Action evet)
        {
            RectTransform kart = ModalKart();
            Ui.Yaz(kart, baslik, 50, Tema.Vurgu, TextAnchor.MiddleCenter, FontStyle.Bold);
            Ui.Yaz(kart, metin, 42, Tema.Yazi);
            Ui.Dugme(kart, evetEtiketi, Tema.Kotu, Color.white, () =>
            {
                ModalKapat();
                if (evet != null) evet();
            });
            Ui.Dugme(kart, "Vazgeç", Tema.PanelAcik, Tema.Yazi, () => ModalKapat());
        }

        /// <summary>Tüm sayfa için dikey kaydırmalı, ortalanmış içerik alanı.</summary>
        private RectTransform Sayfa()
        {
            ScrollRect sr;
            RectTransform icerik = Ui.Kaydirma(ekran, 48, 24, out sr);
            return icerik;
        }

        // ------------------------------------------------------------------
        // Kayıt
        // ------------------------------------------------------------------

        /// <summary>Etkin yuvaya kaydeder. zorla=false iken otomatik kayıt ayarına uyar.</summary>
        private void KaydetYuva(bool zorla)
        {
            if (aktifYuva < 1 || hayat == null) return;
            if (!zorla && !Tema.OtoKayit) return;
            string hata;
            if (!Kayit.Yaz(aktifYuva, hayat, out hata))
            {
                Debug.LogWarning("[Ömür] Kayıt yazılamadı: " + hata);
            }
        }

        private static uint YeniTohum()
        {
            long zaman = DateTime.UtcNow.Ticks;
            long rastgele = UnityEngine.Random.Range(0, int.MaxValue);
            return unchecked((uint)(zaman ^ (rastgele << 7)));
        }
    }
}
