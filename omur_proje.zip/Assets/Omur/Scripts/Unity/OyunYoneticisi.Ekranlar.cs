using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Omur
{
    // Uyarı, ana menü, karakter oluşturma ve doğum ekranları.
    public sealed partial class OyunYoneticisi
    {
        private const string UyariAnahtari = "omur_uyari_ok";

        private void IlkEkran()
        {
            bool onayli = false;
            try
            {
                onayli = PlayerPrefs.GetInt(UyariAnahtari, 0) == 1;
            }
            catch (Exception)
            {
                onayli = false;
            }
            if (onayli) AnaMenu();
            else UyariEkrani();
        }

        // ------------------------------------------------------------------
        // İçerik uyarısı
        // ------------------------------------------------------------------

        private void UyariEkrani()
        {
            Goster(UyariCiz);
        }

        private void UyariCiz()
        {
            RectTransform ic = Sayfa();
            Ui.Bosluk(ic, 120);
            Ui.Yaz(ic, "ÖMÜR", 120, Tema.Vurgu, TextAnchor.UpperCenter, FontStyle.Bold);
            Ui.Bosluk(ic, 30);
            RectTransform kart = Ui.Kart(ic, Tema.Panel, 40, 20);
            Ui.Yaz(kart, "İçerik uyarısı", 52, Tema.Yazi, TextAnchor.UpperLeft, FontStyle.Bold);
            Ui.Yaz(kart, "Bu oyun 18+ temalar içerir: suç, hapis, hastalık ve ölüm gibi konular yer alabilir. Suç özendirilmez; oyundaki her eylemin sonucu vardır.", 42, Tema.Yazi);
            Ui.Yaz(kart, "Gerçek hayatta yasa dışı hiçbir şeyin tarifi ya da yöntemi oyunda yer almaz.", 38, Tema.Soluk);
            Ui.Bosluk(ic, 20);
            Ui.Dugme(ic, "Anladım, devam", Tema.Vurgu, Tema.VurguYazi, () =>
            {
                try
                {
                    PlayerPrefs.SetInt(UyariAnahtari, 1);
                    PlayerPrefs.Save();
                }
                catch (Exception)
                {
                    // Depolama kapalıysa uyarı bir sonraki açılışta yeniden görünür.
                }
                AnaMenu();
            });
        }

        // ------------------------------------------------------------------
        // Ana menü ve kayıt yuvaları
        // ------------------------------------------------------------------

        private void AnaMenu()
        {
            aktifYuva = -1;
            hayat = null;
            motor = null;
            Goster(AnaMenuCiz);
        }

        private void AnaMenuCiz()
        {
            RectTransform ic = Sayfa();
            Ui.Bosluk(ic, 80);
            Ui.Yaz(ic, "ÖMÜR", 130, Tema.Vurgu, TextAnchor.UpperCenter, FontStyle.Bold);
            Ui.Yaz(ic, "Doğ, büyü, bir hayat yaşa.", 44, Tema.Soluk, TextAnchor.UpperCenter, FontStyle.Normal);
            Ui.Bosluk(ic, 30);

            for (int yuva = 1; yuva <= Sabit.YuvaSayisi; yuva++)
            {
                YuvaKarti(ic, yuva);
            }

            Ui.Bosluk(ic, 10);
            Ui.Dugme(ic, "Yedekten yükle (panodan)", Tema.PanelAcik, Tema.Yazi, () => YedektenYukle());
            Ui.Dugme(ic, "Ayarlar", Tema.PanelAcik, Tema.Yazi, () => Goster(MenuAyarlariCiz));
        }

        private void YuvaKarti(RectTransform ic, int yuva)
        {
            RectTransform kart = Ui.Kart(ic, Tema.Panel, 32, 14);
            Ui.Yaz(kart, "Yuva " + yuva, 36, Tema.Soluk, TextAnchor.UpperLeft, FontStyle.Bold);

            int yuvaNo = yuva;
            if (!Kayit.Var(yuva))
            {
                Ui.Yaz(kart, "Boş", 44, Tema.Yazi);
                Ui.Dugme(kart, "Yeni hayat", Tema.Vurgu, Tema.VurguYazi, () => KarakterOlustur(yuvaNo));
                return;
            }

            string hata;
            Hayat h = Kayit.Oku(yuva, out hata);
            if (h == null)
            {
                Ui.Yaz(kart, "Kayıt okunamadı.", 44, Tema.Kotu);
                Ui.Yaz(kart, hata, 34, Tema.Soluk);
                Ui.Dugme(kart, "Bu yuvayı temizle", Tema.PanelAcik, Tema.Yazi, () =>
                    Onay("Yuva temizlensin mi?", "Bozuk kayıt kalıcı olarak silinecek.", "Temizle", () =>
                    {
                        Kayit.Sil(yuvaNo);
                        Yenile();
                    }));
                return;
            }

            Ui.Yaz(kart, Kayit.Ozet(h), 44, Tema.Yazi);
            string devamEtiketi = h.Yasiyor ? "Devam et" : "Hayat özeti";
            Ui.Dugme(kart, devamEtiketi, Tema.Vurgu, Tema.VurguYazi, () => YuvadanDevamEt(yuvaNo));
            Ui.Dugme(kart, "Sil", Tema.PanelAcik, Tema.Kotu, () =>
                Onay("Hayat silinsin mi?", h.TamAd + " adlı hayat kalıcı olarak silinecek.", "Sil", () =>
                {
                    Kayit.Sil(yuvaNo);
                    Yenile();
                }), 38, 100, null, true);
        }

        private void YuvadanDevamEt(int yuva)
        {
            string hata;
            Hayat h = Kayit.Oku(yuva, out hata);
            if (h == null)
            {
                Bilgi("Kayıt açılamadı", hata);
                return;
            }
            aktifYuva = yuva;
            hayat = h;
            motor = new OyunMotoru(hayat);
            sekme = "hayat";
            sonMesaj = "";
            if (!hayat.Yasiyor) OlumEkrani();
            else AnaEkran();
        }

        // ------------------------------------------------------------------
        // Yedek: panodan yükleme
        // ------------------------------------------------------------------

        private void YedektenYukle()
        {
            string pano = GUIUtility.systemCopyBuffer;
            string hata;
            Hayat h = Kayit.Coz(pano, out hata);
            if (h == null)
            {
                Bilgi("Yedek bulunamadı", "Panoda geçerli bir Ömür kaydı yok. Önce başka bir cihazdan 'Yedeği kopyala' ile kopyalayıp buraya gel.\n\nDetay: " + hata);
                return;
            }

            RectTransform kart = ModalKart();
            Ui.Yaz(kart, "Hangi yuvaya yüklensin?", 48, Tema.Vurgu, TextAnchor.MiddleCenter, FontStyle.Bold);
            Ui.Yaz(kart, Kayit.Ozet(h), 40, Tema.Yazi, TextAnchor.UpperCenter, FontStyle.Normal);
            for (int yuva = 1; yuva <= Sabit.YuvaSayisi; yuva++)
            {
                int yuvaNo = yuva;
                string etiket = "Yuva " + yuva + (Kayit.Var(yuva) ? " (üzerine yazılır)" : " (boş)");
                Ui.Dugme(kart, etiket, Tema.PanelAcik, Tema.Yazi, () =>
                {
                    string yazmaHata;
                    bool tamam = Kayit.Yaz(yuvaNo, h, out yazmaHata);
                    ModalKapat();
                    if (tamam)
                    {
                        Bilgi("Yüklendi", "Kayıt yuva " + yuvaNo + "'e yazıldı.");
                        Yenile();
                    }
                    else
                    {
                        Bilgi("Yüklenemedi", yazmaHata);
                    }
                });
            }
            Ui.Dugme(kart, "Vazgeç", Tema.PanelAcik, Tema.Soluk, () => ModalKapat());
        }

        // ------------------------------------------------------------------
        // Karakter oluşturma
        // ------------------------------------------------------------------

        private void KarakterOlustur(int yuva)
        {
            string cinsiyet = "Rastgele";
            string secilenIl = null;
            Goster(() => KarakterOlusturCiz(yuva, cinsiyet, secilenIl, "", ""));
        }

        private void KarakterOlusturCiz(int yuva, string cinsiyet, string secilenIl, string ad, string soyad)
        {
            RectTransform ic = Sayfa();
            Ui.Yaz(ic, "Yeni hayat", 80, Tema.Vurgu, TextAnchor.UpperCenter, FontStyle.Bold);
            Ui.Yaz(ic, "Adını ve soyadını yaz; sonra dünyaya gel.", 42, Tema.Soluk, TextAnchor.UpperCenter, FontStyle.Normal);

            InputField adGirdi = Ui.Girdi(ic, "Ad", 20);
            adGirdi.text = ad;
            InputField soyadGirdi = Ui.Girdi(ic, "Soyad", 20);
            soyadGirdi.text = soyad;

            // Cinsiyet seçimi
            Ui.Yaz(ic, "Cinsiyet", 38, Tema.Soluk, TextAnchor.UpperLeft, FontStyle.Bold);
            RectTransform cinsiyetSatiri = Ui.Nesne("Cinsiyet", ic);
            Ui.Yatay(cinsiyetSatiri.gameObject, 14, 0, 0, 0, 0);
            Ui.Yukseklik(cinsiyetSatiri.gameObject, 120, 120);
            string[] cinsiyetler = new string[] { "Erkek", "Kadın", "Rastgele" };
            for (int i = 0; i < cinsiyetler.Length; i++)
            {
                string c = cinsiyetler[i];
                bool secili = c == cinsiyet;
                Ui.Dugme(cinsiyetSatiri, c, secili ? Tema.Vurgu : Tema.PanelAcik, secili ? Tema.VurguYazi : Tema.Yazi, () =>
                {
                    KarakterOlusturCiz2(yuva, c, secilenIl, adGirdi.text, soyadGirdi.text);
                }, 40, 120, null, true);
            }

            // Doğum yeri
            Ui.Yaz(ic, "Doğum yeri", 38, Tema.Soluk, TextAnchor.UpperLeft, FontStyle.Bold);
            string ilYazisi = string.IsNullOrEmpty(secilenIl) ? "Rastgele" : secilenIl;
            Ui.Dugme(ic, ilYazisi, Tema.PanelAcik, Tema.Yazi, () =>
            {
                IlSecici(yuva, cinsiyet, adGirdi.text, soyadGirdi.text);
            });

            // Rastgele isim
            Ui.Dugme(ic, "Rastgele ad ve soyad", Tema.PanelAcik, Tema.Yazi, () =>
            {
                string secilen = cinsiyet;
                System.Random rnd = new System.Random();
                if (secilen != "Erkek" && secilen != "Kadın") secilen = rnd.Next(2) == 0 ? "Erkek" : "Kadın";
                string[] adlar = secilen == "Erkek" ? Isimler.ErkekAdlari : Isimler.KadinAdlari;
                string yeniAd = adlar[rnd.Next(adlar.Length)];
                string yeniSoyad = Isimler.Soyadlari[rnd.Next(Isimler.Soyadlari.Length)];
                KarakterOlusturCiz2(yuva, secilen, secilenIl, yeniAd, yeniSoyad);
            });

            Ui.Bosluk(ic, 10);
            Ui.Dugme(ic, "Dünyaya gel", Tema.Vurgu, Tema.VurguYazi, () =>
            {
                string temizAd = Tr.AdTemizle(adGirdi.text, 20);
                string temizSoyad = Tr.AdTemizle(soyadGirdi.text, 20);
                if (temizAd.Length == 0 || temizSoyad.Length == 0)
                {
                    Bilgi("Eksik bilgi", "Lütfen ad ve soyad gir. (Yalnızca harf, boşluk ve tire kullanılır.)");
                    return;
                }
                HayataBasla(yuva, temizAd, temizSoyad, cinsiyet, secilenIl);
            });
            Ui.Dugme(ic, "Geri", Tema.PanelAcik, Tema.Soluk, () => AnaMenu());
        }

        /// <summary>Seçimler değişince formu girilen metinleri koruyarak yeniden çizer.</summary>
        private void KarakterOlusturCiz2(int yuva, string cinsiyet, string secilenIl, string ad, string soyad)
        {
            Goster(() => KarakterOlusturCiz(yuva, cinsiyet, secilenIl, ad, soyad));
        }

        private void IlSecici(int yuva, string cinsiyet, string ad, string soyad)
        {
            RectTransform liste = ModalListe("Doğum yeri", "Vazgeç");
            Ui.Dugme(liste, "Rastgele", Tema.Vurgu, Tema.VurguYazi, () =>
            {
                KarakterOlusturCiz2(yuva, cinsiyet, null, ad, soyad);
            }, 40, 110, null, true);
            string[] sinifAdi = new string[] { "büyükşehir", "orta şehir", "küçük şehir" };
            for (int i = 0; i < Isimler.Iller.Length; i++)
            {
                IlBilgi il = Isimler.Iller[i];
                string ilAdi = il.Ad;
                Ui.Dugme(liste, ilAdi, Tema.PanelAcik, Tema.Yazi, () =>
                {
                    KarakterOlusturCiz2(yuva, cinsiyet, ilAdi, ad, soyad);
                }, 40, 110, sinifAdi[il.Sinif], true);
            }
        }

        private void HayataBasla(int yuva, string ad, string soyad, string cinsiyet, string il)
        {
            aktifYuva = yuva;
            hayat = OyunMotoru.YeniHayat(ad, soyad, cinsiyet, il, YeniTohum(), DateTime.Now.Year);
            motor = new OyunMotoru(hayat);
            sekme = "hayat";
            sonMesaj = "";
            KaydetYuva(true);
            Goster(DogumCiz);
        }

        private void DogumCiz()
        {
            RectTransform ic = Sayfa();
            Ui.Bosluk(ic, 80);
            Ui.Yaz(ic, "Dünyaya geldin", 76, Tema.Vurgu, TextAnchor.UpperCenter, FontStyle.Bold);
            Ui.Bosluk(ic, 20);
            RectTransform kart = Ui.Kart(ic, Tema.Panel, 40, 22);
            for (int i = 0; i < hayat.Gunluk.Count && i < 3; i++)
            {
                Ui.Yaz(kart, hayat.Gunluk[i].Metin, 44, Tema.Yazi);
            }
            RectTransform stat = Ui.Kart(ic, Tema.Panel, 32, 8);
            Ui.Yaz(stat, "Başlangıç özelliklerin", 38, Tema.Soluk, TextAnchor.UpperLeft, FontStyle.Bold);
            Ui.StatCubugu(stat, "Sağlık", hayat.Saglik, Tema.Iyi);
            Ui.StatCubugu(stat, "Zekâ", hayat.Zeka, Color.Lerp(Tema.Yazi, Color.cyan, 0.5f));
            Ui.StatCubugu(stat, "Görünüm", hayat.Gorunum, Tema.Vurgu);
            Ui.StatCubugu(stat, "Sosyallik", hayat.Sosyallik, Tema.Vurgu);
            Ui.StatCubugu(stat, "Disiplin", hayat.Disiplin, Tema.Vurgu);
            Ui.Bosluk(ic, 10);
            Ui.Dugme(ic, "Hayata başla", Tema.Vurgu, Tema.VurguYazi, () => AnaEkran());
        }
    }
}
