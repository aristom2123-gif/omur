using UnityEngine;

namespace Omur
{
    /// <summary>Renkler ve kullanıcı ayarları (koyu/açık tema, yazı boyutu, şans göstergesi).</summary>
    public static class Tema
    {
        public static bool Koyu = true;
        public static int YaziBoyutu = 1;          // 0 küçük, 1 normal, 2 büyük
        public static bool SansYuzdeGoster = false; // false: Yüksek/Orta/Düşük, true: yüzde
        public static bool OtoKayit = true;

        public static float YaziOlcek
        {
            get
            {
                if (YaziBoyutu == 0) return 0.9f;
                if (YaziBoyutu == 2) return 1.15f;
                return 1f;
            }
        }

        private static Color Renk(string hex)
        {
            Color c;
            if (!ColorUtility.TryParseHtmlString("#" + hex, out c)) c = Color.magenta;
            return c;
        }

        public static Color Zemin { get { return Koyu ? Renk("12161C") : Renk("F2EFE8"); } }
        public static Color Panel { get { return Koyu ? Renk("1D232C") : Renk("FFFFFF"); } }
        public static Color PanelAcik { get { return Koyu ? Renk("2A323D") : Renk("E4E0D5"); } }
        public static Color Yazi { get { return Koyu ? Renk("ECEFF4") : Renk("1B1F24"); } }
        public static Color Soluk { get { return Koyu ? Renk("9CA7B6") : Renk("5A6370"); } }
        public static Color Vurgu { get { return Renk("E8A33D"); } }
        public static Color VurguYazi { get { return Renk("1B1F24"); } }
        public static Color Iyi { get { return Koyu ? Renk("5CC27A") : Renk("2E8B4F"); } }
        public static Color Kotu { get { return Koyu ? Renk("E5675E") : Renk("C0392B"); } }
        public static Color Dim { get { return new Color(0f, 0f, 0f, 0.7f); } }

        public static void Yukle()
        {
            try
            {
                Koyu = PlayerPrefs.GetInt("omur_koyu", 1) == 1;
                YaziBoyutu = Mathf.Clamp(PlayerPrefs.GetInt("omur_yazi", 1), 0, 2);
                SansYuzdeGoster = PlayerPrefs.GetInt("omur_sans_yuzde", 0) == 1;
                OtoKayit = PlayerPrefs.GetInt("omur_otokayit", 1) == 1;
            }
            catch (System.Exception)
            {
                // Ayarlar okunamazsa varsayılanlarla devam edilir.
            }
        }

        public static void Kaydet()
        {
            try
            {
                PlayerPrefs.SetInt("omur_koyu", Koyu ? 1 : 0);
                PlayerPrefs.SetInt("omur_yazi", YaziBoyutu);
                PlayerPrefs.SetInt("omur_sans_yuzde", SansYuzdeGoster ? 1 : 0);
                PlayerPrefs.SetInt("omur_otokayit", OtoKayit ? 1 : 0);
                PlayerPrefs.Save();
            }
            catch (System.Exception)
            {
                // Depolama kapalı ya da dolu olabilir.
            }
        }
    }
}
