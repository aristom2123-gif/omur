using UnityEngine;

namespace Omur
{
    /// <summary>
    /// Sahne kurmaya gerek bırakmaz: herhangi bir sahne yüklendiğinde oyunu kendiliğinden başlatır.
    /// (Projede sahne olması yeterli; boş sahne de olur.)
    /// </summary>
    public static class Onyukleyici
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Baslat()
        {
            if (OyunYoneticisi.Ornek != null) return;
            GameObject go = new GameObject("OmurOyunYoneticisi");
            go.AddComponent<OyunYoneticisi>();
            Object.DontDestroyOnLoad(go);
        }
    }
}
