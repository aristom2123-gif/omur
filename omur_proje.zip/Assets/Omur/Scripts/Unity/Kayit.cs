using System;
using System.IO;
using UnityEngine;

namespace Omur
{
    /// <summary>
    /// Kayıt yuvaları (1-3), dışa ve içe aktarma. Tüm dosya işlemleri try/catch içindedir.
    /// Kayıtlar Application.persistentDataPath altında JSON dosyasıdır.
    /// </summary>
    public static class Kayit
    {
        private const int EnFazlaKarakter = 1000000;

        public static string Yol(int yuva)
        {
            return Path.Combine(Application.persistentDataPath, "omur_yuva" + yuva + ".json");
        }

        public static bool Var(int yuva)
        {
            try
            {
                return File.Exists(Yol(yuva));
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static bool Yaz(int yuva, Hayat h, out string hata)
        {
            hata = "";
            try
            {
                string json = JsonUtility.ToJson(h, false);
                string yol = Yol(yuva);
                string gecici = yol + ".tmp";
                File.WriteAllText(gecici, json);
                if (File.Exists(yol)) File.Delete(yol);
                File.Move(gecici, yol);
                return true;
            }
            catch (Exception e)
            {
                hata = e.Message;
                return false;
            }
        }

        public static Hayat Oku(int yuva, out string hata)
        {
            hata = "";
            try
            {
                string yol = Yol(yuva);
                if (!File.Exists(yol))
                {
                    hata = "Kayıt yok.";
                    return null;
                }
                string json = File.ReadAllText(yol);
                return Coz(json, out hata);
            }
            catch (Exception e)
            {
                hata = e.Message;
                return null;
            }
        }

        public static void Sil(int yuva)
        {
            try
            {
                string yol = Yol(yuva);
                if (File.Exists(yol)) File.Delete(yol);
            }
            catch (Exception)
            {
                // Silinemeyen dosya bir sonraki yazmada üzerine yazılır.
            }
        }

        public static string Disa(Hayat h)
        {
            return JsonUtility.ToJson(h, false);
        }

        /// <summary>JSON metnini güvenli bir hayata çevirir. Dışarıdan yapıştırılan metin için de kullanılır.</summary>
        public static Hayat Coz(string json, out string hata)
        {
            hata = "";
            if (string.IsNullOrEmpty(json))
            {
                hata = "Metin boş.";
                return null;
            }
            string kirpilmis = json.Trim();
            if (kirpilmis.Length < 2 || kirpilmis[0] != '{')
            {
                hata = "Geçerli bir kayıt metni değil.";
                return null;
            }
            if (kirpilmis.Length > EnFazlaKarakter)
            {
                hata = "Kayıt metni çok büyük.";
                return null;
            }

            try
            {
                Hayat h = JsonUtility.FromJson<Hayat>(kirpilmis);
                if (h == null)
                {
                    hata = "Kayıt okunamadı.";
                    return null;
                }
                h.Dogrula();
                h.Ad = Tr.AdTemizle(h.Ad, 20);
                h.Soyad = Tr.AdTemizle(h.Soyad, 20);
                if (h.Ad.Length == 0 || h.Soyad.Length == 0)
                {
                    hata = "Kayıtta ad ya da soyad yok.";
                    return null;
                }
                if (h.Gunluk.Count > Sabit.GunlukSiniri)
                {
                    h.Gunluk.RemoveRange(0, h.Gunluk.Count - Sabit.GunlukSiniri);
                    h.GunlukKirpildi = true;
                }
                Goc(h);
                return h;
            }
            catch (Exception e)
            {
                hata = e.Message;
                return null;
            }
        }

        /// <summary>Eski sürüm kayıtlarını yeni biçime taşır (şimdilik tek sürüm var).</summary>
        private static void Goc(Hayat h)
        {
            if (h.Surum < Sabit.KayitSurumu) h.Surum = Sabit.KayitSurumu;
        }

        /// <summary>Yuva kartında gösterilecek tek satır özet.</summary>
        public static string Ozet(Hayat h)
        {
            string durum = h.Yasiyor ? h.Yas + " yaş" : h.OlumYasi + " yaşında öldü";
            return h.TamAd + " · " + durum + " · " + h.Il;
        }
    }
}
