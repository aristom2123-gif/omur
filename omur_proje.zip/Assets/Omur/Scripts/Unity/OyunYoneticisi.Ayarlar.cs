using System;
using UnityEngine;
using UnityEngine.UI;

namespace Omur
{
    // Ayarlar: tema, yazı boyutu, şans göstergesi, otomatik kayıt, yedek, kaydı silme, içerik uyarısı.
    public sealed partial class OyunYoneticisi
    {
        private void MenuAyarlariCiz()
        {
            RectTransform ic = Sayfa();
            Ui.Yaz(ic, "Ayarlar", 76, Tema.Vurgu, TextAnchor.UpperCenter, FontStyle.Bold);
            AyarlariCiz(ic, false);
            Ui.Dugme(ic, "Geri", Tema.Vurgu, Tema.VurguYazi, () => AnaMenu());
        }

        /// <summary>Ayar düğmelerini verilen içerik alanına çizer. oyunda=true ise oyun içi kayıt seçenekleri de görünür.</summary>
        private void AyarlariCiz(RectTransform ic, bool oyunda)
        {
            RectTransform gorunum = Ui.Kart(ic, Tema.Panel, 24, 12);
            Ui.Yaz(gorunum, "Görünüm ve oynanış", 38, Tema.Soluk, TextAnchor.UpperLeft, FontStyle.Bold);

            Ui.Dugme(gorunum, "Tema: " + (Tema.Koyu ? "Koyu" : "Açık"), Tema.PanelAcik, Tema.Yazi, () =>
            {
                Tema.Koyu = !Tema.Koyu;
                Tema.Kaydet();
                Yenile();
            }, 40, 110, null, true);

            string[] boyutlar = new string[] { "Küçük", "Normal", "Büyük" };
            Ui.Dugme(gorunum, "Yazı boyutu: " + boyutlar[Mathf.Clamp(Tema.YaziBoyutu, 0, 2)], Tema.PanelAcik, Tema.Yazi, () =>
            {
                Tema.YaziBoyutu = (Tema.YaziBoyutu + 1) % 3;
                Tema.Kaydet();
                Yenile();
            }, 40, 110, null, true);

            Ui.Dugme(gorunum, "Şans göstergesi: " + (Tema.SansYuzdeGoster ? "Yüzde" : "Yüksek / Orta / Düşük"), Tema.PanelAcik, Tema.Yazi, () =>
            {
                Tema.SansYuzdeGoster = !Tema.SansYuzdeGoster;
                Tema.Kaydet();
                Yenile();
            }, 40, 110, null, true);

            Ui.Dugme(gorunum, "Otomatik kayıt: " + (Tema.OtoKayit ? "Açık" : "Kapalı"), Tema.PanelAcik, Tema.Yazi, () =>
            {
                Tema.OtoKayit = !Tema.OtoKayit;
                Tema.Kaydet();
                Yenile();
            }, 40, 110, null, true);

            RectTransform kayit = Ui.Kart(ic, Tema.Panel, 24, 12);
            Ui.Yaz(kayit, "Kayıt ve yedek", 38, Tema.Soluk, TextAnchor.UpperLeft, FontStyle.Bold);

            if (oyunda)
            {
                Ui.Dugme(kayit, "Şimdi kaydet", Tema.PanelAcik, Tema.Yazi, () =>
                {
                    KaydetYuva(true);
                    Bilgi("Kaydedildi", "Hayatın yuva " + aktifYuva + "'e kaydedildi.");
                }, 40, 110, null, true);

                Ui.Dugme(kayit, "Yedeği kopyala (pano)", Tema.PanelAcik, Tema.Yazi, () =>
                {
                    GUIUtility.systemCopyBuffer = Kayit.Disa(hayat);
                    Bilgi("Kopyalandı", "Kayıt metni panoya kopyalandı. Bir not uygulamasına yapıştırıp saklayabilirsin; uygulamayı silsen bile 'Yedekten yükle' ile geri dönebilirsin.");
                }, 40, 110, null, true);
            }

            Ui.Dugme(kayit, "Yedekten yükle (panodan)", Tema.PanelAcik, Tema.Yazi, () => YedektenYukle(), 40, 110, null, true);

            if (oyunda)
            {
                Ui.Dugme(kayit, "Kaydı sil", Tema.PanelAcik, Tema.Kotu, () =>
                    Onay("Kayıt silinsin mi?", "Bu yuvadaki hayat kalıcı olarak silinecek.", "Sil", () =>
                    {
                        Kayit.Sil(aktifYuva);
                        AnaMenu();
                    }), 40, 110, null, true);

                Ui.Dugme(kayit, "Ana menüye dön", Tema.PanelAcik, Tema.Yazi, () =>
                {
                    KaydetYuva(false);
                    AnaMenu();
                }, 40, 110, null, true);
            }

            RectTransform diger = Ui.Kart(ic, Tema.Panel, 24, 12);
            Ui.Yaz(diger, "Diğer", 38, Tema.Soluk, TextAnchor.UpperLeft, FontStyle.Bold);
            Ui.Dugme(diger, "İçerik uyarısını yeniden göster", Tema.PanelAcik, Tema.Yazi, () =>
            {
                try
                {
                    PlayerPrefs.DeleteKey(UyariAnahtari);
                    PlayerPrefs.Save();
                }
                catch (Exception)
                {
                    // Depolama kapalıysa uyarı zaten her açılışta gösterilir.
                }
                UyariEkrani();
            }, 40, 110, null, true);
            Ui.Yaz(diger, "Ömür  ·  Faz 1 (Çekirdek)", 32, Tema.Soluk, TextAnchor.UpperCenter, FontStyle.Normal);
        }
    }
}
