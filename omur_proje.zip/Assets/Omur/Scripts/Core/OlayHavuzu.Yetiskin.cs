using System;
using System.Collections.Generic;

namespace Omur
{
    public static partial class OlayHavuzu
    {
        // Yetişkinlik olayları (22-64 yaş civarı). İş ve ekonomi olayları 3. fazda zenginleşecek.
        private static void YetiskinEkle(List<Olay> l)
        {
            l.Add(Y.Oto("komsu_cay", HavuzTuru.Aile, 30, 90, "sos+2 mut+2",
                "Komşun seni çaya çağırdı; bir saatlik ziyaret üç saate uzadı.",
                "Apartmanda yeni taşınan komşuyla tanıştın; sohbet ayaküstü başladı, merdivende bitti."));

            l.Add(Y.Karar("saglik_kontrolu", HavuzTuru.Saglik, 30, 85,
                "Yıllık sağlık kontrolü zamanı geldi.|Doktor randevunu kaçıra kaçıra bir yıl geçirdin; bu kez hatırlattılar.",
                Y.SecSans("Kapsamlı kontrol yaptır", 70, "zek:0.1",
                    Y.Sn("Erken uyarı aldın; küçük bir sorun büyümeden fark edildi.", "sag+4 str-2"),
                    Y.Sn("Her şey normal çıktı; yine de içini rahatlattı.", "sag+1 mut+1"))
                    .UcretEkle(2500)
                    .Sart(d => d.Para >= 2500),
                Y.Sec("Ertele", "Kontrolü yine erteledin; takvimin tek suçlusu sen değilsin.", "sag-1")).Agir(14));

            l.Add(Y.Karar("araba_bozuldu", HavuzTuru.Ekonomi, 22, 70,
                "Arabanın motoru tuhaf sesler çıkarıyor.|Yolda arabanın gösterge ışıkları yılbaşı ağacına döndü.",
                Y.Sec("Servise götür", "Usta sorunu buldu ve düzeltti; fatura biraz sıkıntılı ama araba yürüyor.", "str-1 mut-1 para-6000")
                    .Sart(d => d.Para >= 6000),
                Y.SecSans("Kendin bakmaya çalış", 35, "zek:0.3,dis:0.1",
                    Y.Sn("Videoyu izledin, anahtarı aldın ve bir şeyleri düzelttin; araba gerçekten çalıştı.", "para-500 zek+2 mut+3"),
                    Y.Sn("Şimdi hem araba hem sen yağ içindesin; yine de bir şey öğrendin.", "para-3000 mut-2 str+2")),
                Y.Sec("Toplu taşımaya geç", "Bir süre otobüs ve yürüyüşle idare ettin; ayakların itiraz etse de cebin rahatladı.", "sag+1 str+1")).Agir(8));

            l.Add(Y.Karar("komsu_gurultu", HavuzTuru.Aile, 25, 85,
                "Üst komşun akşamları davul çalışıyor.|Alt kat komşun müziği geceleri fazla yükseltiyor.",
                Y.SecSans("Nazikçe uyar", 55, "sos:0.3",
                    Y.Sn("Komşun özür diledi ve çay ikram etti.", "sos+3 str-2 itb+1"),
                    Y.Sn("Biraz gerginlik oldu ama ses azaldı.", "str+2 sos-1")),
                Y.Sec("Kulaklık tak", "Kulaklıkla yaşamayı seçtin; sorun bitmedi ama duyulmaz oldu.", "str+1 mut-1"),
                Y.Sec("Yöneticiye şikâyet et", "Yönetici konuyu ele aldı; komşunla bakışmalar bir süre soğuk geçti.", "str-1 sos-1")).Agir(8));

            l.Add(Y.Karar("eski_dost", HavuzTuru.Aile, 25, 85,
                "Çocukluk arkadaşından beklenmedik bir mesaj geldi.|Eski bir dostun yıllar sonra seni sosyal medyada buldu.",
                Y.Sec("Buluş", "Uzun uzun konuştunuz; eski hikâyeler yeniden canlandı.", "sos+3 mut+5"),
                Y.Sec("Mesajı cevapla, buluşma", "Birkaç sıcak cümle yazdınız; bağ kopmadı ama yakınlaşmadınız.", "sos+1 mut+1"),
                Y.Sec("Görmezden gel", "Mesajı okudun ve unuttun; içinde küçük bir boşluk kaldı.", "mut-1 sos-1")).Agir(8));

            l.Add(Y.Karar("piyango", HavuzTuru.Ekonomi, 22, 80,
                "Sokak başındaki bayi sana şans getireceğini söyleyerek bir bilet uzattı.",
                Y.SecSans("Bilet al", 4, "",
                    Y.Sn("Küçük bir ikramiye kazandın! Şaşkınlıktan bileti iki kez kontrol ettin.", "para+30000 mut+5"),
                    Y.Sn("Bilet bir şey çıkarmadı; kâğıt parçası olarak saklarsın.", "mut-1"))
                    .Kritik(Y.Sn("Büyük ikramiye! Önce inanmadın, sonra bayiyi aradın.", "para+500000 mut+10 itb+1"),
                            Y.Sn("Bilet bir şey çıkarmadı; hatta cebindeki biletin kendisini de kaybettin.", "mut-2"))
                    .UcretEkle(200)
                    .Sart(d => d.Para >= 200),
                Y.Sec("Yürüyüp geç", "Biletsiz yoluna devam ettin; şans bir başka sefere.", "dis+1")).Agir(5));

            l.Add(Y.Karar("kira_artisi", HavuzTuru.Ekonomi, 22, 70,
                "Ev sahibin kirayı ciddi biçimde artırmak istiyor.|Mektup geldi: kira artışı beklediğinden fazla.",
                Y.SecSans("Pazarlık et", 40, "sos:0.3,zek:0.1",
                    Y.Sn("Makul bir artışa ikna ettin; ev sahibi bile sana saygı duydu.", "str+1 mut+1"),
                    Y.Sn("Pazarlık tutmadı; ağır bir artışı kabul ettin.", "mut-3 str+3")),
                Y.Sec("Taşın", "Yeni bir ev aradın; taşınma zor ama yeni bir başlangıç oldu.", "str+3 mut-1 sos-1"),
                Y.Sec("Kabul et", "Artışı kabul ettin; bütçen biraz daraldı.", "mut-2 str+1")).Agir(8));

            l.Add(Y.Karar("deprem_hazirlik", HavuzTuru.Genel, 25, 80,
                "Deprem çantası hazırlamak ve evi güçlendirmek aklına düştü.",
                Y.Sec("Hazırlık yap", "Çantayı hazırladın, mobilyaları sabitledin; içini rahatlatan bir gün oldu.", "str-3 mut+1 itb+1 para-1500 +b:deprem_cantasi")
                    .Sart(d => d.Para >= 1500),
                Y.Sec("Sonraya bırak", "Çanta listede kaldı; dünya yine dönüyor.", "str+1")).Bir().Agir(6));

            l.Add(Y.Karar("tatil", HavuzTuru.Genel, 22, 80,
                "Biriken izinlerini kullanma zamanı geldi.|Takvime baktın; izin günlerin sayfanın taşıyordu.",
                Y.Sec("Deniz kenarı tatili", "Güneşte yandın, denizde çoktun; harika bir tatil geçirdin.", "mut+7 str-6 sag+2 para-15000")
                    .Sart(d => d.Para >= 15000),
                Y.Sec("Köy evinde dinlen", "Horoz sesiyle uyandın, çimlerde yürüdün; hiçbir şey yapmadın ve çok iyi geldi.", "mut+4 str-4 sag+2"),
                Y.Sec("Evde kitap oku", "Üç kitap bitirdin; kanepede geçen güzel bir tatildi.", "mut+2 zek+2 str-2")).Agir(10));

            l.Add(Y.Karar("spor_salonu", HavuzTuru.Saglik, 22, 55,
                "Spor salonu üyeliğinde yılbaşı indirimi var.|Mahalledeki spor salonu açılış kampanyası yapıyor.",
                Y.SecSans("Üye ol", 50, "dis:0.3",
                    Y.Sn("Düzenli gittin; hem formun hem keyfin yerine geldi.", "sag+5 gor+3 dis+3 str-2"),
                    Y.Sn("İlk ay gittin, sonra kart cüzdanda uyudu.", "mut-1 dis-1"))
                    .UcretEkle(6000)
                    .Sart(d => d.Para >= 6000),
                Y.Sec("Pas geç", "Evde egzersizle idare ettin; biraz da bahane buldun.", "mut-1")).Agir(8));

            l.Add(Y.Karar("ofis_yemegi", HavuzTuru.Genel, 25, 60,
                "İş arkadaşların ofis dışında bir yemek planlıyor.|Arkadaşların akşam yemeği için sana davet gönderdi.",
                Y.Sec("Git", "Yemek güzeldi, sohbet daha da güzeldi; hesabı bölüşürken biraz uğraştınız.", "sos+3 mut+3 para-800")
                    .Sart(d => d.Para >= 800),
                Y.Sec("Evde dinlen", "Evde battaniyenin altında film izledin; en iyi plan buydu.", "str-1 mut+1")).Agir(10));

            l.Add(Y.Karar("doga_yuruyusu", HavuzTuru.Saglik, 20, 75,
                "Hafta sonu için doğa yürüyüşü planı var.|Bir arkadaşın seni dağ yürüyüşüne çağırdı.",
                Y.SecSans("Katıl", 70, "sag:0.2",
                    Y.Sn("Manzara muhteşemdi; yorgunluk bile güzeldi.", "sag+3 mut+4 sos+2"),
                    Y.Sn("Dönüşte ayağın şişti ama manzara yine güzeldi.", "sag-1 mut+3")),
                Y.Sec("Evde kal", "Hafta sonunu evde geçirdin; kanepe de bir doğa parçasıdır.", "mut-1")).Agir(10));

            l.Add(Y.Karar("yemek_kursu", HavuzTuru.Genel, 22, 65,
                "Mahalle kültür merkezinde yemek kursu açılmış.|Bir arkadaşın seni birlikte yemek kursuna yazılmaya ikna etmeye çalışıyor.",
                Y.SecSans("Katıl", 60, "dis:0.2,zek:0.1",
                    Y.Sn("Mantı katlayabilir hale geldin; arkadaşların artık sana yemek ısmarlamıyor, sen yapıyorsun.", "mut+4 sos+3 zek+1 +b:yemek_yapar"),
                    Y.Sn("Tuzu üçüncü kez kovmadan atamadın ama eğlendin.", "mut+1 sos+2"))
                    .UcretEkle(1000)
                    .Sart(d => d.Para >= 1000),
                Y.Sec("Katılma", "Kurs başka bir yıla kaldı.", "mut-1")).Bir().Agir(8));

            l.Add(Y.Karar("viral_video", HavuzTuru.Genel, 16, 45,
                "Paylaştığın bir video beklenmedik şekilde yayıldı.|Bir paylaşımın bir gecede binlerce kişiye ulaştı.",
                Y.SecSans("Devam et, yeni videolar çek", 40, "sos:0.2,gor:0.2",
                    Y.Sn("Takipçilerin arttı; küçük bir reklam geliri geldi.", "itb+2 sos+3 para+4000 mut+4"),
                    Y.Sn("Beğeniler azaldı ama videolar çekmek hoşuna gitti.", "mut+1 str+1")),
                Y.Sec("Sil, yoluna bak", "Paylaşımı sildin; dikkat çekmekten hoşlanmıyorsun.", "str-2")).Bir().Agir(6));

            l.Add(Y.Karar("dag_yuruyusu", HavuzTuru.Saglik, 16, 60,
                "Arkadaşlarla dağ yürüyüşündesiniz; hava aniden bozuldu.",
                Y.SecSans("Geri dön", 80, "dis:0.2,zek:0.1",
                    Y.Sn("Zamanında döndünüz; çaylarınızı şelaleye bakarak içtiniz.", "str+2 itb+1 dis+1"),
                    Y.Sn("Üşüdün ve yolu zor buldun ama sağ salim indin.", "sag-5 mut-1"))
                    .Kritik(Y.Sn("Rehber gibi davrandın; ekibi güvenle indirdin.", "itb+3 dis+2 sos+2"),
                            Y.Sn("Kayganlık yüzünden ciddi bir kaza yaşandı.", "olum:Dağ_yürüyüşünde_yaşanan_bir_kaza")),
                Y.SecSans("İleri git", 45, "sag:0.2,dis:0.2",
                    Y.Sn("Hava yine de düzeldi; zirveye çıkıp manzaraya doyduk.", "mut+6 sos+3 sag+1"),
                    Y.Sn("Hava kötüleşti; çok zor durumda kaldınız ama kurtuldunuz.", "sag-8 str+5 mut-3"))
                    .Kritik(Y.Sn("Zirveye çıktın; unutulmaz bir gün oldu.", "mut+8 sos+4"),
                            Y.Sn("Kayganlık yüzünden ciddi bir kaza yaşandı.", "olum:Dağ_yürüyüşünde_yaşanan_bir_kaza"))).Agir(4));
        }
    }
}
