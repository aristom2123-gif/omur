using System;
using System.Collections.Generic;

namespace Omur
{
    /// <summary>
    /// Olay havuzu (15. bölüm). Olaylar veri olarak yazılır; motor koşullara göre seçer.
    /// Olaylar OlayHavuzu.*.cs dosyalarında yaş dönemine göre ayrılmıştır.
    /// </summary>
    public static partial class OlayHavuzu
    {
        private static List<Olay> tum;
        private static Dictionary<string, Olay> sozluk;

        public static List<Olay> Tum
        {
            get
            {
                Hazirla();
                return tum;
            }
        }

        public static Olay Bul(string id)
        {
            Hazirla();
            Olay o;
            if (!string.IsNullOrEmpty(id) && sozluk.TryGetValue(id, out o)) return o;
            return null;
        }

        private static void Hazirla()
        {
            if (tum != null) return;
            List<Olay> l = new List<Olay>();
            CocuklukEkle(l);
            GenclikEkle(l);
            YetiskinEkle(l);
            YaslilikEkle(l);

            Dictionary<string, Olay> s = new Dictionary<string, Olay>();
            for (int i = 0; i < l.Count; i++)
            {
                if (!s.ContainsKey(l[i].Id)) s.Add(l[i].Id, l[i]);
            }
            sozluk = s;
            tum = l;
        }

        /// <summary>Veri hatalarını (yinelenen kimlik, kırık zincir, boş metin...) listeler. Boşsa her şey yolunda.</summary>
        public static List<string> Dogrula()
        {
            Hazirla();
            List<string> sorunlar = new List<string>();
            HashSet<string> gorulen = new HashSet<string>();

            for (int i = 0; i < tum.Count; i++)
            {
                Olay o = tum[i];
                if (string.IsNullOrEmpty(o.Id)) sorunlar.Add("Kimliksiz olay (sıra " + i + ")");
                if (!gorulen.Add(o.Id)) sorunlar.Add("Yinelenen olay kimliği: " + o.Id);
                if (o.MinYas > o.MaxYas) sorunlar.Add(o.Id + ": en az yaş en çok yaştan büyük");
                if (o.Metin == null || o.Metin.Length == 0) sorunlar.Add(o.Id + ": metin yok");
                if (o.Secenekler.Count == 0 && o.Otomatik == null) sorunlar.Add(o.Id + ": ne seçenek ne otomatik sonuç var");
                if (o.Secenekler.Count > 4) sorunlar.Add(o.Id + ": 4'ten fazla seçenek");

                if (o.Otomatik != null) ZincirKontrol(o.Id, o.Otomatik, sorunlar);
                for (int k = 0; k < o.Secenekler.Count; k++)
                {
                    Secenek sc = o.Secenekler[k];
                    if (string.IsNullOrEmpty(sc.Etiket)) sorunlar.Add(o.Id + ": boş seçenek etiketi");
                    if (sc.Basari == null) sorunlar.Add(o.Id + "/" + sc.Etiket + ": başarı sonucu yok");
                    if (sc.Sans != null && sc.Basarisiz == null) sorunlar.Add(o.Id + "/" + sc.Etiket + ": şanslı ama başarısızlık sonucu yok");
                    ZincirKontrol(o.Id, sc.Basari, sorunlar);
                    ZincirKontrol(o.Id, sc.Basarisiz, sorunlar);
                    ZincirKontrol(o.Id, sc.KritikBasari, sorunlar);
                    ZincirKontrol(o.Id, sc.KritikBasarisiz, sorunlar);
                }
            }

            for (int i = 0; i < Etki.Hatalar.Count; i++) sorunlar.Add(Etki.Hatalar[i]);
            return sorunlar;
        }

        private static void ZincirKontrol(string olayId, Sonuc s, List<string> sorunlar)
        {
            if (s == null) return;
            if (!string.IsNullOrEmpty(s.Etki.Zincir) && !sozluk.ContainsKey(s.Etki.Zincir))
            {
                sorunlar.Add(olayId + ": zincir hedefi yok: " + s.Etki.Zincir);
            }
        }
    }
}
