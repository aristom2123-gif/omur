using System;
using System.Collections.Generic;

namespace Omur
{
    public static partial class OlayHavuzu
    {
        // Olgunluk ve yaşlılık olayları (55+ yaş).
        private static void YaslilikEkle(List<Olay> l)
        {
            l.Add(Y.Oto("eski_fotograf", HavuzTuru.Aile, 60, 100, "mut+2 str-1",
                "Sandıktan eski fotoğraflar çıktı; bol bol güldün, biraz da gözlerin doldu.",
                "Eski bir albüme baktın; herkes bir zamanlar çok gençti."));

            l.Add(Y.Karar("bahce_ugrasi", HavuzTuru.Genel, 55, 95,
                "Bir arkadaşın sana bahçe için fidan getirdi.|Balkonundaki saksılar için yeni tohumlar buldun.",
                Y.SecSans("Fidanları ek", 70, "sag:0.1",
                    Y.Sn("Toprakla uğraşmak iyi geldi; fidanlar umut verici görünüyor.", "sag+2 mut+4 +b:bahce"),
                    Y.Sn("Biraz sırtın tutuldu ama domatesler umut verici.", "sag-1 mut+2")),
                Y.Sec("Başkasına ver", "Fidanları komşuna hediye ettin; çaylar senden.", "sos+2 mut+1")).Bir().Agir(10));

            l.Add(Y.Karar("yuruyus_onerisi", HavuzTuru.Saglik, 60, 95,
                "Doktor günlük yürüyüş önerdi.|Doktorun 'Her gün yirmi dakika' dedi; sen takvime baktın.",
                Y.SecSans("Her gün yürü", 60, "dis:0.3",
                    Y.Sn("Her gün yürüdün; adımların sağlamlaştı, ruh halin açıldı.", "sag+4 mut+2 str-2"),
                    Y.Sn("İlk hafta güzeldi, sonra bahaneler başladı.", "sag+1")),
                Y.Sec("Bırak, gerek yok", "Koltuk kalıpların daha rahat; sağlık ise biraz azaldı.", "sag-2")).Agir(10));

            l.Add(Y.Karar("tansiyon", HavuzTuru.Saglik, 55, 100,
                "Doktor tansiyonunun yüksek olduğunu söyledi.|Rutin kontrolde tansiyonun sınırın üzerinde çıktı.",
                Y.SecSans("İlaçlarını düzenli kullan", 70, "dis:0.3",
                    Y.Sn("İlaçları düzenli aldın; tansiyonun kontrol altına girdi.", "sag+4 str-1"),
                    Y.Sn("Bazı günler unuttun ama genel gidiş fena değil.", "sag+1")),
                Y.Sec("Umursama", "Doktorun uyarılarını geçiştirdin; vücudun bunu unutmaz.", "sag-4 str+2")).Agir(10));

            l.Add(Y.Karar("mahalle_kahvesi", HavuzTuru.Genel, 55, 100,
                "Mahalle kahvesinde eski bir tavla rakibin seni bekliyor.|Eski dostların tavla masasında yer ayırmış.",
                Y.SecSans("Tavla oyna", 50, "zek:0.2",
                    Y.Sn("Üç oyunu üst üste kazandın; çaylar rakibinden.", "mut+4 sos+3 itb+1"),
                    Y.Sn("Bir hafta boyunca çay ısmarladın; eğlenceliydi.", "mut+2 sos+3 para-200")),
                Y.Sec("Evde kal", "Pencerenin önünde oturdun; sokak seni izledi.", "mut-1 sos-1")).Agir(10));

            l.Add(Y.Karar("anilari_anlat", HavuzTuru.Genel, 60, 100,
                "Okulda anı anlatmak için seni davet ettiler.|Mahalle derneği, gençlere hayat hikâyeni anlatmanı istiyor.",
                Y.SecSans("Git ve anlat", 70, "sos:0.2",
                    Y.Sn("Çocuklar nefes almadan dinledi; konuşman alkışla bitti.", "itb+4 mut+4 sos+3"),
                    Y.Sn("Biraz heyecanlandın ama çocukların alkışı yetti.", "mut+3 itb+2")),
                Y.Sec("Daveti reddet", "Teşekkür edip kibarca geri çevirdin.", "mut-1")).Bir().Agir(8));

            l.Add(Y.Karar("merdiven_kazasi", HavuzTuru.Saglik, 65, 100,
                "Evde merdiven çıkarken ayağın kaydı.|Islak zeminde dengen bir anda bozuldu.",
                Y.SecSans("Korkuluğa tutunmaya çalış", 55, "sag:0.3",
                    Y.Sn("Tutundun; sadece kalbin hızlı attı.", "str+2"),
                    Y.Sn("Düştün; kalça çevresinde ağrı var, birkaç hafta yatman gerekecek.", "sag-8 mut-3"))
                    .Kritik(Y.Sn("Refleksinle toparlandın; bir şey olmadı bile.", "mut+1 dis+1"),
                            Y.Sn("Kötü düştün; uzun bir tedavi süreci seni bekliyor.", "sag-18 mut-6")),
                Y.Sec("Yardım çağır", "Bağırdın, komşular koştu; küçük bir sıyrıkla atlattın.", "sag-2 sos+1 str+1")).Agir(5));
        }
    }
}
