using System;
using System.Collections.Generic;

namespace Omur
{
    /// <summary>Oyunun sihirli sayıları tek yerde.</summary>
    public static class Sabit
    {
        public const int KayitSurumu = 1;
        public const int YuvaSayisi = 3;
        public const int GunlukSiniri = 200;
        public const int GunlukKirpma = 20;
        public const int OlayTekrarYili = 5;
        public const int YillikEnCokOlay = 4;
        public const int KritikYuzde = 5;
        public const int SansAlt = 2;
        public const int SansUst = 98;
        public const int EnYuksekYas = 120;
        public const int YanIsBasariGeliri = 30000;
        public const int YanIsBasarisizGeliri = 12000;
        public const int DoktorUcreti = 1500;
        public const int ResitlikYasi = 18;
    }

    /// <summary>Oyuncu istatistikleri (5. bölüm).</summary>
    public enum Istat
    {
        Saglik = 0,
        Mutluluk = 1,
        Zeka = 2,
        Gorunum = 3,
        Sosyallik = 4,
        Disiplin = 5,
        Sans = 6,
        Itibar = 7,
        Stres = 8,
        Arananlik = 9
    }

    public static class IstatBilgi
    {
        public const int Adet = 10;

        private static readonly string[] Kisa =
        {
            "sag", "mut", "zek", "gor", "sos", "dis", "sans", "itb", "str", "ara"
        };

        private static readonly string[] Gorunen =
        {
            "Sağlık", "Mutluluk", "Zekâ", "Görünüm", "Sosyallik", "Disiplin", "Şans", "İtibar", "Stres", "Arananlık"
        };

        public static string KisaAd(Istat i) { return Kisa[(int)i]; }

        public static string GorunenAd(Istat i) { return Gorunen[(int)i]; }

        public static bool KisaAdtanBul(string kisa, out Istat sonuc)
        {
            for (int i = 0; i < Kisa.Length; i++)
            {
                if (Kisa[i] == kisa)
                {
                    sonuc = (Istat)i;
                    return true;
                }
            }
            sonuc = Istat.Saglik;
            return false;
        }
    }
}
