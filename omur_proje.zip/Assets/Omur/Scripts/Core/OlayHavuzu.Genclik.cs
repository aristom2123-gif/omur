using System;
using System.Collections.Generic;

namespace Omur
{
    public static partial class OlayHavuzu
    {
        // Gençlik olayları (12-25 yaş civarı).
        private static void GenclikEkle(List<Olay> l)
        {
            l.Add(Y.Karar("sinav_stresi", HavuzTuru.Okul, 13, 19,
                "Büyük bir sınav haftası yaklaşıyor; masan kitaplarla doldu.|Sınav takvimi açıklandı; herkesin yüzü bir anda ciddileşti.",
                Y.SecSans("Planlı çalış", 50, "zek:0.3,dis:0.3",
                    Y.Sn("Her gün biraz çalıştın; sınavdan önceki gece huzurla uyudun.", "zek+3 dis+3 str+3"),
                    Y.Sn("Plan yaptın ama sınav yine de zordu.", "zek+1 str+4 mut-2")),
                Y.SecSans("Son geceye bırak", 35, "zek:0.3",
                    Y.Sn("Son gece mucizesi gerçekleşti; kahve ve inatla başardın.", "zek+2 str+4 sag-1"),
                    Y.Sn("Sabaha karşı uykuya yenildin; sınav kâbus gibi geçti.", "str+6 mut-3 sag-2")),
                Y.SecSans("Arkadaşlarla birlikte çalış", 50, "sos:0.2,zek:0.2",
                    Y.Sn("Birbirinize soru sordunuz; birlikte öğrenmek daha eğlenceliymiş.", "zek+2 sos+2 mut+2"),
                    Y.Sn("Çalışmaktan çok sohbet ettiniz ama moraliniz yerindeydi.", "mut+1 sos+2"))).Agir(14));

            l.Add(Y.Karar("ilk_ask", HavuzTuru.Genclik, 14, 22,
                "Sınıftan biri hoşuna gitmeye başladı; her baktığında kalbin sekiyor.|Okulun bahçesinde sürekli aynı kişiyle göz göze geliyorsun.",
                Y.SecSans("Duygularını açıkla", 40, "sos:0.3,gor:0.2",
                    Y.Sn("Karşılık buldun! Eller terledi, kalpler hızlandı.", "mut+8 sos+3 str-1 +b:ilk_ask_var zincir:ask_sonrasi"),
                    Y.Sn("Reddedildin ama dürüst davrandığın için kendine saygın arttı.", "mut-5 dis+1 sos+1")),
                Y.SecSans("Mektup yaz", 45, "zek:0.2,sos:0.1",
                    Y.Sn("Mektubun etkili oldu; cevap olarak küçük bir not aldın.", "mut+6 zek+1 +b:ilk_ask_var zincir:ask_sonrasi"),
                    Y.Sn("Mektup elden ele dolaştı; bütün sınıf okudu.", "mut-3 itb-1 sos-1")),
                Y.Sec("Uzaktan izle", "Sessizce hayranlık duydun; bu da bir hikâye sayılır.", "mut-1 str+1")).Bir().Agir(20));

            l.Add(Y.Karar("ask_sonrasi", HavuzTuru.Genclik, 15, 26,
                "İlişkin bir yıl sonra kritik bir noktaya geldi; konuşmak gerekiyor.|Sevgilinle ilişkiniz zorlanmaya başladı.",
                Y.SecSans("Devam etmeyi dene", 50, "sos:0.2,dis:0.1",
                    Y.Sn("Açık konuştunuz; ilişkiniz derinleşti, anılar biriktirdiniz.", "mut+5 sos+2 +b:iliski"),
                    Y.Sn("Yollarınız ayrıldı; zor ama gerekliydi.", "mut-6 str+2 -b:ilk_ask_var")),
                Y.Sec("Arkadaş kalın", "Sakin bir ayrılık oldu; sonrasında selam vermek zor değildi.", "mut-1 sos+1 -b:ilk_ask_var"),
                Y.Sec("Mesafe koy", "Bir süre görüşmediniz; zaman her şeyi netleştirdi.", "str-1 mut-2")).Agir(0));

            l.Add(Y.Karar("sigara_teklif", HavuzTuru.Genclik, 14, 19,
                "Arkadaş grubunda biri sana sigara uzattı; herkes sana bakıyor.",
                Y.SecSans("Hayır de", 65, "dis:0.3",
                    Y.Sn("Hayır dedin; kimse üstelemedi, hatta biri sessizce saygı duydu.", "dis+2 itb+1"),
                    Y.Sn("Hayır dedin ama dalga geçtiler; yine de dik durdun.", "dis+1 sos-1")),
                Y.Sec("Dene", "Boğazın yandı; bir daha asla dedin... ya da dediğini sandın.", "sag-3 dis-2 mut-1 +b:sigara_denedi")).Bir().Agir(12));

            l.Add(Y.Karar("telefon_bagimlilik", HavuzTuru.Genclik, 12, 30,
                "Ekran sürenin fark ettirmeden günde sekiz saate çıktığını gördün.|Telefonun haftalık rapor verdi: ekran süresi göz korkutucu.",
                Y.SecSans("Telefonu bırakıp yürüyüşe çık", 50, "dis:0.3",
                    Y.Sn("Yürüyüş iyi geldi; başın hafifledi, gece daha iyi uyudun.", "sag+3 str-3 dis+2 mut+2"),
                    Y.Sn("İlk saat güzeldi, sonra telefona geri döndün.", "mut-1")),
                Y.Sec("Uygulama sınırlayıcı kur", "Sınırlayıcı bir süre işe yaradı; sınırı atlama yöntemleri bulmak da bir uğraş oldu.", "dis+1 str-1"),
                Y.Sec("Böyle devam et", "Parmakların ekranda uçtu; gözlerin biraz yoruldu.", "mut+1 sag-2 dis-2 zek-1")).Agir(10));

            l.Add(Y.Karar("gitar", HavuzTuru.Genclik, 11, 30,
                "Bir arkadaşın sana gitar çalmayı öğretmek istiyor.|Eski bir gitar buldun; arkadaşın 'Üç akor yeter' dedi.",
                Y.SecSans("Kabul et ve çalış", 45, "dis:0.3,zek:0.1",
                    Y.Sn("Üç akor öğrendin ve ilk şarkıyı çalabildin; herkes dinledi.", "mut+5 sos+3 zek+2 +b:gitar"),
                    Y.Sn("Parmakların şişti ama gitar köşede bekliyor.", "mut-1 dis+1")),
                Y.Sec("Vazgeç", "Gitar bir köşede kaldı; belki bir gün.", "mut-1")).Bir().Agir(12));

            l.Add(Y.Karar("spor_takimi", HavuzTuru.Genclik, 12, 22,
                "Okulun spor takımı deneme seçmeleri yapıyor.|Takım seçmeleri ilan edildi; bir arkadaşın seni yazdırdı bile.",
                Y.SecSans("Seçmelere katıl", 45, "sag:0.3,dis:0.2",
                    Y.Sn("Seçildin! Antrenmanlar yorucu ama takımla birlikte olmak çok güzel.", "sag+4 sos+4 dis+3 mut+3 +b:spor_takimi"),
                    Y.Sn("Seçilemedin ama antrenör seni gelecek yıl için not aldı.", "mut-2 dis+1")),
                Y.Sec("Katılma", "Seçmeleri uzaktan izledin; belki daha sonra.", "mut-1")).Bir().Agir(12));

            l.Add(Y.Karar("yaz_isi", HavuzTuru.Genclik, 15, 24,
                "Yaz için bir arkadaşın sana kafede iş buldu.|Mahalledeki bir dükkân yaz için yardımcı arıyor.",
                Y.SecSans("Çalış", 60, "dis:0.2,sos:0.2",
                    Y.Sn("İlk maaşını aldın! Ayakların ağrıdı ama cebin doldu.", "para+6000 dis+3 sos+2 str+2"),
                    Y.Sn("Patron bir ay sonra seni göndermek zorunda kaldı.", "para+1500 mut-2")),
                Y.Sec("Tatil yap", "Yazı denizde ve uykuda geçirdin; hiçbir şeye pişman değilsin.", "mut+5 sag+2 sos+2")).Agir(12));

            l.Add(Y.Karar("ehliyet", HavuzTuru.Genclik, 18, 30,
                "Ehliyet kursuna yazılma zamanı geldi; yol hâlâ biraz korkutuyor.",
                Y.SecSans("Kursa yaz", 55, "dis:0.2,zek:0.2",
                    Y.Sn("Direksiyon sınavında paralel park yaptın; hoca bile şaşırdı.", "mut+4 dis+2 +b:ehliyet"),
                    Y.Sn("Direksiyonu geçemedin; ek ders almak lazım.", "mut-3 str+2"))
                    .UcretEkle(12000)
                    .Sart(d => d.Para >= 12000),
                Y.Sec("Sonra bakarım", "Ehliyet bir sonraki yıla kaldı.", "mut-1")).Bir().Agir(15));

            l.Add(Y.Karar("gonullu", HavuzTuru.Genclik, 14, 40,
                "Mahalledeki hayvan barınağı gönüllü arıyor.|Bir barınak sosyal medyada yardım çağrısı yaptı.",
                Y.SecSans("Gönüllü ol", 70, "sos:0.1",
                    Y.Sn("Köpek tasmaları, kedi mamaları... Sevgi dolu bir hafta sonu geçirdin.", "mut+4 itb+3 sos+3 +b:hayvan_sever"),
                    Y.Sn("Çok yoruldun ama gönülden bir iş yaptın.", "sag-1 mut+1 itb+2")),
                Y.Sec("Mama bağışla", "Küçük bir bağışla barınağın bir haftalık mamasına katkı yaptın.", "itb+2 mut+2 para-300"),
                Y.Sec("Bu sefer geç", "Başka bir zaman, dedin kendine.", "mut-1")).Bir().Agir(10));

            l.Add(Y.Karar("gece_gezme", HavuzTuru.Genclik, 16, 25,
                "Arkadaşların bütün gece dışarıda kalmayı planlıyor; ama sabah erken kalkman gerek.",
                Y.SecSans("Git", 60, "dis:0.1",
                    Y.Sn("Sabaha kadar sohbet ettiniz; eğlenceliydi.", "mut+5 sos+3 sag-2"),
                    Y.Sn("Uykusuzluktan ertesi gün bayıldın.", "sag-3 mut+1 dis-2 str+2")),
                Y.Sec("Evde kal", "Erken yattın; ertesi gün gözlerin pırıl pırıldı.", "dis+2 sag+1 mut-1")).Agir(10));

            l.Add(Y.Karar("internet_oyun", HavuzTuru.Genclik, 12, 28,
                "Online oyunda ekibin seni turnuvaya çağırdı.|Arkadaşların oyun turnuvasına takım kuruyor ve seni istiyor.",
                Y.SecSans("Katıl", 45, "zek:0.2,dis:0.1",
                    Y.Sn("İkinci oldunuz! Küçük bir ödül ve çok büyük bir gurur.", "para+1500 mut+5 sos+3"),
                    Y.Sn("Eleme turunda elendiniz ama çok eğlendiniz.", "mut+1 sos+2 sag-1")),
                Y.Sec("Bu kez geç", "Başka zaman, dedin; gece boyunca uyudun.", "dis+1")).Agir(10));

            l.Add(Y.Karar("staj_firsati", HavuzTuru.Genclik, 17, 25,
                "Bir yaz stajı fırsatı çıktı; başvuru için görüşme gerekiyor.",
                Y.SecSans("Görüşmeye git", 40, "sos:0.3,zek:0.2",
                    Y.Sn("Görüşmeyi geçtin! Staj boyunca çok şey öğrendin.", "itb+3 zek+2 sos+2 para+3000 +b:staj"),
                    Y.Sn("Seçilemedin ama görüşme deneyimi kazandın.", "sos+1 mut-2")),
                Y.Sec("Pas geç", "Fırsat kaçtı; belki bir sonraki yıl.", "mut-1")).Bir().Agir(12));
        }
    }
}
