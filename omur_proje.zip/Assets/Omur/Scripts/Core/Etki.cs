using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Omur
{
    /// <summary>
    /// Bir sonucun etkisi. Kısa metinle yazılır:
    ///   "mut+5 sag-3 para-200 +b:kedi -b:hasta zincir:ask_sonrasi olum:Kaza_nedeniyle"
    /// İstatistik kısa adları: sag mut zek gor sos dis sans itb str ara. Boşluklar için '_' kullanılır.
    /// </summary>
    public sealed class Etki
    {
        public int[] Fark = new int[IstatBilgi.Adet];
        public long Para;
        public List<string> BayrakEkle = new List<string>();
        public List<string> BayrakSil = new List<string>();
        public string Olum = "";
        public string Zincir = "";

        /// <summary>Çözümleme sırasında bulunan yazım hataları (veri doğrulaması için).</summary>
        public static readonly List<string> Hatalar = new List<string>();

        public static Etki Cozumle(string kaynak)
        {
            Etki e = new Etki();
            if (string.IsNullOrEmpty(kaynak)) return e;

            string[] parcalar = kaynak.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            for (int p = 0; p < parcalar.Length; p++)
            {
                string t = parcalar[p];
                if (t.StartsWith("+b:", StringComparison.Ordinal))
                {
                    e.BayrakEkle.Add(t.Substring(3));
                }
                else if (t.StartsWith("-b:", StringComparison.Ordinal))
                {
                    e.BayrakSil.Add(t.Substring(3));
                }
                else if (t.StartsWith("olum:", StringComparison.Ordinal))
                {
                    e.Olum = t.Substring(5).Replace('_', ' ');
                }
                else if (t.StartsWith("zincir:", StringComparison.Ordinal))
                {
                    e.Zincir = t.Substring(7);
                }
                else
                {
                    int isaret = t.IndexOfAny(new char[] { '+', '-' });
                    if (isaret <= 0)
                    {
                        Hatalar.Add("Etki çözülemedi: '" + t + "' (" + kaynak + ")");
                        continue;
                    }
                    string anahtar = t.Substring(0, isaret);
                    string sayiMetni = t.Substring(isaret);
                    long deger;
                    if (!long.TryParse(sayiMetni, NumberStyles.Integer, CultureInfo.InvariantCulture, out deger))
                    {
                        Hatalar.Add("Etki sayısı okunamadı: '" + t + "' (" + kaynak + ")");
                        continue;
                    }
                    if (anahtar == "para")
                    {
                        e.Para += deger;
                    }
                    else
                    {
                        Istat istat;
                        if (IstatBilgi.KisaAdtanBul(anahtar, out istat))
                        {
                            e.Fark[(int)istat] += (int)deger;
                        }
                        else
                        {
                            Hatalar.Add("Bilinmeyen istatistik: '" + anahtar + "' (" + kaynak + ")");
                        }
                    }
                }
            }
            return e;
        }

        /// <summary>Etkiyi hayata uygular. Ölüm kararını motor verir; burada yalnızca değerler değişir.</summary>
        public void Uygula(Hayat h)
        {
            for (int i = 0; i < IstatBilgi.Adet; i++)
            {
                if (Fark[i] != 0) h.Ekle((Istat)i, Fark[i]);
            }
            h.Para += Para;
            if (h.Para < 0) h.Para = 0; // Borç sistemi 3. fazda gelecek
            for (int i = 0; i < BayrakEkle.Count; i++) h.BayrakEkle(BayrakEkle[i]);
            for (int i = 0; i < BayrakSil.Count; i++) h.BayrakSil(BayrakSil[i]);
            if (!string.IsNullOrEmpty(Zincir)) h.ZincirOlay = Zincir;
        }

        /// <summary>Oyuncuya gösterilen kısa özet: "Mutluluk +5 · Para -200 TL". Gizli Şans gösterilmez.</summary>
        public string Ozet()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < IstatBilgi.Adet; i++)
            {
                if (Fark[i] == 0) continue;
                if ((Istat)i == Istat.Sans) continue;
                if ((Istat)i == Istat.Arananlik && Fark[i] == 0) continue;
                if (sb.Length > 0) sb.Append("  ·  ");
                sb.Append(IstatBilgi.GorunenAd((Istat)i));
                sb.Append(' ');
                sb.Append(Fark[i] > 0 ? "+" : "");
                sb.Append(Fark[i]);
            }
            if (Para != 0)
            {
                if (sb.Length > 0) sb.Append("  ·  ");
                sb.Append("Para ");
                sb.Append(Para > 0 ? "+" : "-");
                sb.Append(Tr.TL(Math.Abs(Para)));
            }
            return sb.ToString();
        }
    }
}
