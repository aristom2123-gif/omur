using System;
using System.Collections.Generic;
using System.Text;

namespace Omur
{
    /// <summary>
    /// Denge testi için hayatları otomatik oynatır (20. bölüm).
    /// Politika: 0 = rastgele seçim, 1 = en yüksek şanslı seçenek, 2 = şanssız (ihtiyatlı) seçenek.
    /// </summary>
    public static class Simulasyon
    {
        public sealed class HayatSonucu
        {
            public int OlumYasi;
            public string Neden = "";
            public int OlaySayisi;
            public int SonSaglik;
            public int SonMutluluk;
            public long SonPara;
        }

        public static HayatSonucu SimuleEt(uint tohum, int politika)
        {
            Rastgele secimRng = Rastgele.Bagimsiz(tohum ^ 0x9E3779B9u);
            Hayat h = OyunMotoru.YeniHayat("Test", "Kişi", "Rastgele", null, tohum, 2026);
            OyunMotoru m = new OyunMotoru(h);

            int guvenlik = 0;
            while (h.Yasiyor && guvenlik < 200)
            {
                guvenlik++;
                EylemleriYap(m, h);

                YilRaporu rap = m.YilBaslat();
                if (rap.Oldu) break;

                Olay o = m.SonrakiSecimliOlay();
                while (o != null)
                {
                    m.Sec(SecimSec(m, o, politika, secimRng));
                    if (!h.Yasiyor) break;
                    o = m.SonrakiSecimliOlay();
                }
                if (!h.Yasiyor) break;
                m.YilBitir();
            }

            HayatSonucu s = new HayatSonucu();
            s.OlumYasi = h.Yasiyor ? h.Yas : h.OlumYasi;
            s.Neden = h.OlumNedeni;
            s.OlaySayisi = h.ToplamOlay;
            s.SonSaglik = h.Saglik;
            s.SonMutluluk = h.Mutluluk;
            s.SonPara = h.Para;
            return s;
        }

        private static void EylemleriYap(OyunMotoru m, Hayat h)
        {
            string neden;
            int deneme = 0;
            while (h.KalanEylem > 0 && deneme < 10)
            {
                deneme++;
                string id;
                if (h.Saglik < 55) id = "doktor";
                else if (h.Stres > 55) id = "dinlen";
                else if (h.Yas < 25 && h.Zeka < 70) id = "ders";
                else if (h.Yas >= 16 && h.Yas < 65 && h.Para < 20000) id = "yan_is";
                else if (h.Saglik < 80) id = "spor";
                else id = "sosyal";

                Eylem e = Eylemler.Bul(id);
                if (e == null || !m.EylemYapilabilir(e, out neden))
                {
                    // Ücretli ya da uygun olmayan eylem yerine ücretsiz birine geç.
                    e = Eylemler.Bul("dinlen");
                    if (!m.EylemYapilabilir(e, out neden)) return;
                    id = "dinlen";
                }
                m.EylemYap(id);
            }
        }

        private static int SecimSec(OyunMotoru m, Olay o, int politika, Rastgele rng)
        {
            List<int> uygun = new List<int>();
            for (int i = 0; i < o.Secenekler.Count; i++)
            {
                if (m.SecenekKullanilabilir(o.Secenekler[i])) uygun.Add(i);
            }
            if (uygun.Count == 0) return 0;

            if (politika == 1)
            {
                int enIyi = uygun[0];
                int enYuksek = -1;
                for (int i = 0; i < uygun.Count; i++)
                {
                    Secenek s = o.Secenekler[uygun[i]];
                    int y = s.Sans == null ? 50 : SansMotoru.Yuzde(m.H, s.Sans, 0);
                    if (y > enYuksek)
                    {
                        enYuksek = y;
                        enIyi = uygun[i];
                    }
                }
                return enIyi;
            }
            if (politika == 2)
            {
                for (int i = 0; i < uygun.Count; i++)
                {
                    if (o.Secenekler[uygun[i]].Sans == null) return uygun[i];
                }
                return uygun[0];
            }
            return uygun[rng.Aralik(0, uygun.Count - 1)];
        }

        /// <summary>n hayat oynatır ve özet raporu metin olarak döner.</summary>
        public static string Calistir(int hayatSayisi, int politika)
        {
            List<int> yaslar = new List<int>();
            Dictionary<string, int> nedenler = new Dictionary<string, int>();
            long toplamOlay = 0;
            long toplamPara = 0;
            int erkenOlum = 0;   // 18 yaş altı
            int genc = 0;        // 18-39
            int orta = 0;        // 40-64
            int yasli = 0;       // 65-84
            int cokYasli = 0;    // 85+

            for (int i = 0; i < hayatSayisi; i++)
            {
                HayatSonucu s = SimuleEt(unchecked((uint)(i + 1) * 2654435761u), politika);
                yaslar.Add(s.OlumYasi);
                toplamOlay += s.OlaySayisi;
                toplamPara += s.SonPara;
                int adet;
                nedenler.TryGetValue(s.Neden, out adet);
                nedenler[s.Neden] = adet + 1;

                if (s.OlumYasi < 18) erkenOlum++;
                else if (s.OlumYasi < 40) genc++;
                else if (s.OlumYasi < 65) orta++;
                else if (s.OlumYasi < 85) yasli++;
                else cokYasli++;
            }

            yaslar.Sort();
            double ortalama = 0;
            for (int i = 0; i < yaslar.Count; i++) ortalama += yaslar[i];
            ortalama /= Math.Max(1, yaslar.Count);
            int ortanca = yaslar.Count > 0 ? yaslar[yaslar.Count / 2] : 0;

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("== Simülasyon: " + hayatSayisi + " hayat, politika " + politika + " ==");
            sb.AppendLine("Ortalama ömür: " + ortalama.ToString("0.0") + " | ortanca: " + ortanca
                + " | en kısa: " + (yaslar.Count > 0 ? yaslar[0] : 0) + " | en uzun: " + (yaslar.Count > 0 ? yaslar[yaslar.Count - 1] : 0));
            sb.AppendLine("Ölüm dağılımı: 18 altı %" + Yuzde(erkenOlum, hayatSayisi)
                + ", 18-39 %" + Yuzde(genc, hayatSayisi)
                + ", 40-64 %" + Yuzde(orta, hayatSayisi)
                + ", 65-84 %" + Yuzde(yasli, hayatSayisi)
                + ", 85+ %" + Yuzde(cokYasli, hayatSayisi));
            sb.AppendLine("Hayat başına ortalama olay: " + (toplamOlay / (double)Math.Max(1, hayatSayisi)).ToString("0.0")
                + " | ortalama son para: " + Tr.TL(toplamPara / Math.Max(1, hayatSayisi)));
            sb.AppendLine("Ölüm nedenleri:");
            foreach (KeyValuePair<string, int> kv in nedenler)
            {
                sb.AppendLine("  " + kv.Key + ": " + kv.Value);
            }
            return sb.ToString();
        }

        private static string Yuzde(int adet, int toplam)
        {
            return (100.0 * adet / Math.Max(1, toplam)).ToString("0.0");
        }
    }
}
