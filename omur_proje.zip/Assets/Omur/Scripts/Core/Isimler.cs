using System;
using System.Collections.Generic;

namespace Omur
{
    public sealed class IlBilgi
    {
        public string Ad;
        public int Sinif; // 0 büyükşehir, 1 orta, 2 küçük

        public IlBilgi(string ad, int sinif)
        {
            Ad = ad;
            Sinif = sinif;
        }
    }

    /// <summary>Ad, soyad, il ve aile mesleği listeleri (4. bölüm).</summary>
    public static class Isimler
    {
        public static readonly string[] ErkekAdlari =
        {
            "Ahmet", "Mehmet", "Mustafa", "Ali", "Hüseyin", "Hasan", "İbrahim", "İsmail", "Yusuf", "Ömer",
            "Murat", "Emre", "Burak", "Can", "Cem", "Kemal", "Orhan", "Serkan", "Tolga", "Volkan",
            "Barış", "Onur", "Furkan", "Enes", "Eren", "Arda", "Kerem", "Yiğit", "Alper", "Berk",
            "Deniz", "Efe", "Kaan", "Mert", "Oğuz", "Taner", "Uğur", "Selim", "Selçuk", "Süleyman",
            "Recep", "Osman", "Halil", "Fatih", "Kadir", "Metin", "Levent", "Erdem", "Erkan", "Gökhan",
            "Hakan", "Harun", "İlker", "Koray", "Mahir", "Nihat", "Okan", "Polat", "Rıza", "Sinan",
            "Tuncay", "Umut", "Yasin", "Zafer", "Bülent", "Cengiz", "Doğan", "Ercan", "Ferhat", "Güray",
            "Hayri", "İlhan", "Kenan", "Lütfü", "Mazlum", "Nuri", "Oktay", "Rasim", "Sedat", "Turgut",
            "Ümit", "Vedat", "Abdullah", "Bilal", "Cihan", "Davut", "Eyüp", "Fikret", "Galip", "Haluk",
            "Kazım", "Latif", "Necati", "Özgür", "Ramazan", "Salih", "Tarık", "Veli", "Yaşar", "Zeki"
        };

        public static readonly string[] KadinAdlari =
        {
            "Ayşe", "Fatma", "Emine", "Hatice", "Zeynep", "Elif", "Merve", "Büşra", "Esra", "Kübra",
            "Seda", "Gamze", "Ebru", "Özge", "Buse", "Ceren", "Dilara", "Ece", "Gizem", "Hande",
            "İrem", "Melisa", "Nazlı", "Pınar", "Selin", "Sibel", "Tuğba", "Yağmur", "Zehra", "Aslı",
            "Berna", "Cansu", "Derya", "Eda", "Feride", "Gül", "Hülya", "İpek", "Jale", "Kader",
            "Leyla", "Meltem", "Neslihan", "Oya", "Perihan", "Rabia", "Sevgi", "Şeyma", "Tülin", "Ümran",
            "Vildan", "Yasemin", "Zerrin", "Aylin", "Burcu", "Canan", "Duygu", "Esin", "Figen", "Gönül",
            "Havva", "Işıl", "Kezban", "Lale", "Mine", "Nilüfer", "Özlem", "Pelin", "Reyhan", "Songül",
            "Tuba", "Ülkü", "Yıldız", "Zübeyde", "Aysel", "Belgin", "Cemile", "Damla", "Elmas", "Filiz",
            "Gülşen", "Handan", "İlknur", "Lütfiye", "Müge", "Nurcan", "Ruhsar", "Sema", "Tijen", "Nermin",
            "Sultan", "Nihal", "Melek", "Şule", "Çiğdem", "Ayten", "Bahar", "Dilek", "Emel", "Fadime"
        };

        public static readonly string[] Soyadlari =
        {
            "Yılmaz", "Kaya", "Demir", "Şahin", "Çelik", "Yıldız", "Yıldırım", "Öztürk", "Aydın", "Özdemir",
            "Arslan", "Doğan", "Kılıç", "Aslan", "Çetin", "Kara", "Koç", "Kurt", "Özkan", "Şimşek",
            "Polat", "Korkmaz", "Özer", "Çakır", "Erdoğan", "Yavuz", "Can", "Acar", "Şen", "Aksoy",
            "Aktaş", "Güneş", "Tekin", "Karaca", "Bulut", "Türk", "Taş", "Keskin", "Ünal", "Bayram",
            "Gül", "Uçar", "Duman", "Eren", "Karataş", "Avcı", "Sarı", "Bozkurt", "Ateş", "Özgür",
            "Kaplan", "Güler", "Işık", "Tunç", "Er", "Soylu", "Turan", "Akın", "Kalkan", "Çınar",
            "Altun", "Mutlu", "Özyurt", "Coşkun", "Yalçın", "Ay", "Toprak", "Akgün", "Bilgin", "Cengiz",
            "Dalgıç", "Ekinci", "Fidan", "Gökçe", "Hancı", "İnan", "Kahraman", "Metin", "Nalbant", "Oral",
            "Pehlivan", "Sönmez", "Tuna", "Uslu", "Varol", "Yazıcı", "Zengin", "Baysal", "Çiftçi", "Demirci",
            "Ergin", "Güven", "Karakaya", "Memiş", "Ozan", "Sezer", "Tanrıverdi", "Uysal", "Vural", "Yurt"
        };

        public static readonly IlBilgi[] Iller =
        {
            new IlBilgi("Adana", 0), new IlBilgi("Adıyaman", 1), new IlBilgi("Afyonkarahisar", 1),
            new IlBilgi("Ağrı", 1), new IlBilgi("Aksaray", 1), new IlBilgi("Amasya", 2),
            new IlBilgi("Ankara", 0), new IlBilgi("Antalya", 0), new IlBilgi("Ardahan", 2),
            new IlBilgi("Artvin", 2), new IlBilgi("Aydın", 0), new IlBilgi("Balıkesir", 0),
            new IlBilgi("Bartın", 2), new IlBilgi("Batman", 1), new IlBilgi("Bayburt", 2),
            new IlBilgi("Bilecik", 2), new IlBilgi("Bingöl", 2), new IlBilgi("Bitlis", 2),
            new IlBilgi("Bolu", 1), new IlBilgi("Burdur", 2), new IlBilgi("Bursa", 0),
            new IlBilgi("Çanakkale", 1), new IlBilgi("Çankırı", 2), new IlBilgi("Çorum", 1),
            new IlBilgi("Denizli", 0), new IlBilgi("Diyarbakır", 0), new IlBilgi("Düzce", 1),
            new IlBilgi("Edirne", 1), new IlBilgi("Elazığ", 1), new IlBilgi("Erzincan", 2),
            new IlBilgi("Erzurum", 0), new IlBilgi("Eskişehir", 0), new IlBilgi("Gaziantep", 0),
            new IlBilgi("Giresun", 1), new IlBilgi("Gümüşhane", 2), new IlBilgi("Hakkâri", 2),
            new IlBilgi("Hatay", 0), new IlBilgi("Iğdır", 2), new IlBilgi("Isparta", 1),
            new IlBilgi("İstanbul", 0), new IlBilgi("İzmir", 0), new IlBilgi("Kahramanmaraş", 0),
            new IlBilgi("Karabük", 1), new IlBilgi("Karaman", 1), new IlBilgi("Kars", 2),
            new IlBilgi("Kastamonu", 1), new IlBilgi("Kayseri", 0), new IlBilgi("Kırıkkale", 1),
            new IlBilgi("Kırklareli", 1), new IlBilgi("Kırşehir", 2), new IlBilgi("Kilis", 2),
            new IlBilgi("Kocaeli", 0), new IlBilgi("Konya", 0), new IlBilgi("Kütahya", 1),
            new IlBilgi("Malatya", 0), new IlBilgi("Manisa", 0), new IlBilgi("Mardin", 0),
            new IlBilgi("Mersin", 0), new IlBilgi("Muğla", 0), new IlBilgi("Muş", 2),
            new IlBilgi("Nevşehir", 2), new IlBilgi("Niğde", 1), new IlBilgi("Ordu", 0),
            new IlBilgi("Osmaniye", 1), new IlBilgi("Rize", 1), new IlBilgi("Sakarya", 0),
            new IlBilgi("Samsun", 0), new IlBilgi("Siirt", 2), new IlBilgi("Sinop", 2),
            new IlBilgi("Sivas", 1), new IlBilgi("Şanlıurfa", 0), new IlBilgi("Şırnak", 2),
            new IlBilgi("Tekirdağ", 0), new IlBilgi("Tokat", 1), new IlBilgi("Trabzon", 0),
            new IlBilgi("Tunceli", 2), new IlBilgi("Uşak", 1), new IlBilgi("Van", 0),
            new IlBilgi("Yalova", 2), new IlBilgi("Yozgat", 1), new IlBilgi("Zonguldak", 1)
        };

        public static readonly string[] MeslekDusuk =
        {
            "inşaat işçisi", "tekstil işçisi", "şoför", "garson", "temizlik görevlisi",
            "çiftçi", "kasiyer", "berber", "fabrika işçisi", "güvenlik görevlisi", "seyyar satıcı"
        };

        public static readonly string[] MeslekOrta =
        {
            "öğretmen", "memur", "hemşire", "esnaf", "teknisyen", "muhasebeci",
            "bankacı", "taksici", "polis", "elektrikçi", "aşçı"
        };

        public static readonly string[] MeslekYuksek =
        {
            "doktor", "mühendis", "avukat", "işletmeci", "akademisyen", "mimar",
            "müteahhit", "eczacı", "pilot"
        };

        public static IlBilgi IlBul(string ad)
        {
            for (int i = 0; i < Iller.Length; i++)
            {
                if (Iller[i].Ad == ad) return Iller[i];
            }
            return null;
        }
    }
}
