using System;
using System.Globalization;
using System.Text;

namespace Omur
{
    /// <summary>Türkçe metin yardımcıları (kültür verisine bağlı olmayan, cihazdan bağımsız).</summary>
    public static class Tr
    {
        private const string Vokaller = "aeıioöuüâîû";
        private const string Onunlu = "eiöüîi";
        private const string Sert = "çfhkpsşt";

        public static char Buyuk(char c)
        {
            if (c == 'i') return 'İ';
            if (c == 'ı') return 'I';
            return char.ToUpperInvariant(c);
        }

        public static char Kucuk(char c)
        {
            if (c == 'I') return 'ı';
            if (c == 'İ') return 'i';
            return char.ToLowerInvariant(c);
        }

        /// <summary>'ayşe  nur' → 'Ayşe Nur'.</summary>
        public static string BasHarfleriBuyut(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            StringBuilder sb = new StringBuilder();
            bool kelimeBasi = true;
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == ' ' || c == '-' || c == '\'')
                {
                    sb.Append(c);
                    kelimeBasi = true;
                }
                else if (kelimeBasi)
                {
                    sb.Append(Buyuk(c));
                    kelimeBasi = false;
                }
                else
                {
                    sb.Append(Kucuk(c));
                }
            }
            return sb.ToString();
        }

        /// <summary>'Konya' → "Konya'da", 'Kars' → "Kars'ta", 'İzmir' → "İzmir'de".</summary>
        public static string BulunmaEki(string kelime)
        {
            if (string.IsNullOrEmpty(kelime)) return "";
            char son = Kucuk(kelime[kelime.Length - 1]);
            bool sert = Sert.IndexOf(son) >= 0;

            char sonUnlu = 'a';
            for (int i = kelime.Length - 1; i >= 0; i--)
            {
                char c = Kucuk(kelime[i]);
                if (Vokaller.IndexOf(c) >= 0)
                {
                    sonUnlu = c;
                    break;
                }
            }
            bool onUnlu = Onunlu.IndexOf(sonUnlu) >= 0;
            string ek = (sert ? "t" : "d") + (onUnlu ? "e" : "a");
            return kelime + "'" + ek;
        }

        /// <summary>12500 → "12.500".</summary>
        public static string Sayi(long n)
        {
            string s = n.ToString("N0", CultureInfo.InvariantCulture);
            return s.Replace(",", ".");
        }

        public static string TL(long n)
        {
            return Sayi(n) + " TL";
        }

        /// <summary>Kullanıcı girdisi: harf, boşluk, tire ve kesme işareti dışındakileri atar, kırpar.</summary>
        public static string AdTemizle(string s, int enFazla)
        {
            if (s == null) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (char.IsLetter(c) || c == ' ' || c == '-' || c == '\'')
                {
                    sb.Append(c);
                }
            }
            string t = sb.ToString().Trim();
            while (t.Contains("  ")) t = t.Replace("  ", " ");
            if (t.Length > enFazla) t = t.Substring(0, enFazla).Trim();
            return BasHarfleriBuyut(t);
        }
    }
}
