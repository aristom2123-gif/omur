using System;
using System.Collections.Generic;

namespace Omur
{
    /// <summary>Oyuncunun yıllık eylem hakkıyla seçtiği eylemler (3. bölüm).</summary>
    public sealed class Eylem
    {
        public string Id = "";
        public string Ad = "";
        public string Aciklama = "";
        public int MinYas;
        public int MaxYas = 120;
        public long Ucret;          // 18 yaşından sonra oyuncu öder; çocuklar için aile öder
        public SansTanim Sans;      // null ise şanssız
        public Sonuc Basari;
        public Sonuc Basarisiz;
    }

    public static class Eylemler
    {
        public static readonly List<Eylem> Liste = Olustur();

        public static Eylem Bul(string id)
        {
            for (int i = 0; i < Liste.Count; i++)
            {
                if (Liste[i].Id == id) return Liste[i];
            }
            return null;
        }

        private static Eylem E(string id, string ad, string aciklama, int minYas, int maxYas, long ucret,
            int taban, string etkenler,
            string basariMetin, string basariEtki, string basarisizMetin, string basarisizEtki)
        {
            Eylem e = new Eylem();
            e.Id = id;
            e.Ad = ad;
            e.Aciklama = aciklama;
            e.MinYas = minYas;
            e.MaxYas = maxYas;
            e.Ucret = ucret;
            e.Basari = Y.Sn(basariMetin, basariEtki);
            if (taban >= 0)
            {
                e.Sans = SansTanim.Olustur(taban, etkenler, 0);
                e.Basarisiz = Y.Sn(basarisizMetin, basarisizEtki);
            }
            return e;
        }

        private static List<Eylem> Olustur()
        {
            List<Eylem> l = new List<Eylem>();

            l.Add(E("ders", "Ders çalış", "Zekâ ve Disiplin artar; Stres yükselir.", 6, 30, 0,
                50, "zek:0.3,dis:0.3",
                "Verimli bir çalışma yılı geçirdin.", "zek+3 dis+1 str+2 mut-1",
                "Odaklanmakta zorlandın; yine de bir şeyler kaldı.", "zek+1 str+3 mut-2"));

            l.Add(E("spor", "Spor yap", "Sağlık ve Disiplin artar; Stres azalır.", 6, 85, 0,
                55, "sag:0.2,dis:0.2",
                "Düzenli antrenman yaptın; kendini zinde hissediyorsun.", "sag+2 dis+2 gor+1 str-2 mut+1",
                "Antrenmanlar yarım kaldı ama yine de hareket ettin.", "sag+1 str-1"));

            l.Add(E("sosyal", "Sosyalleş", "Sosyallik ve Mutluluk artar.", 6, 95, 0,
                55, "sos:0.3,gor:0.1",
                "Yeni insanlarla tanıştın; sohbetler güzeldi.", "sos+3 mut+3 str-2",
                "Sohbet bir türlü ısınmadı ama denedin.", "sos+1"));

            l.Add(E("dinlen", "Dinlen", "Stres azalır, Mutluluk artar.", 6, 100, 0,
                -1, "",
                "Kendine zaman ayırdın; bir fincan çay ve biraz sessizlik.", "str-6 mut+2 sag+1",
                "", ""));

            l.Add(E("aile", "Aileyle vakit geçir", "Mutluluk artar, Stres azalır.", 6, 100, 0,
                -1, "",
                "Ailenle uzun bir sofra kurdunuz; kahkahalar eksik olmadı.", "mut+3 str-3 sos+1",
                "", ""));

            l.Add(E("ogren", "Yeni bir şey öğren", "Zekâ ve Mutluluk artar.", 6, 75, 0,
                55, "zek:0.3",
                "Yeni bir beceri edinmek hoşuna gitti.", "zek+2 mut+3 str-1",
                "Konu zor çıktı ama merakın uyandı.", "mut+1"));

            l.Add(E("yan_is", "Yan iş yap", "Para kazanırsın; Stres biraz artar.", 16, 70, 0,
                60, "dis:0.2,sos:0.2",
                "Yan işte iyi iş çıkardın; cebin doldu.", "para+" + Sabit.YanIsBasariGeliri + " str+3 dis+1",
                "Yan iş verimsiz geçti; yine de biraz kazandın.", "para+" + Sabit.YanIsBasarisizGeliri + " str+4 mut-1"));

            l.Add(E("doktor", "Doktora git", "Sağlık iyileşir. 18 yaşından sonra ücretlidir.", 6, 100, Sabit.DoktorUcreti,
                65, "zek:0.1",
                "Doktor doğru teşhisi koydu ve tedaviye başladınız.", "sag+6 str-2 mut+1",
                "Tedavi zor ilerledi ama durumun kötüleşmedi.", "sag+2 mut-1"));

            return l;
        }
    }
}
