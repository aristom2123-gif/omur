using System;
using System.Collections.Generic;

namespace Omur
{
    /// <summary>
    /// Tohumlu rastgele sayı üretici (mulberry32). Durum doğrudan Hayat nesnesinde tutulur;
    /// bu yüzden kayıt-yükle yapınca aynı sonuçlar çıkar (kaydet-yükle hilesi çalışmaz).
    /// </summary>
    public sealed class Rastgele
    {
        private readonly Hayat hayat;

        public Rastgele(Hayat hayat)
        {
            this.hayat = hayat;
        }

        /// <summary>Bir hayata bağlı olmayan, yalnızca tohuma bağlı üretici (testler ve arayüz için).</summary>
        public static Rastgele Bagimsiz(uint tohum)
        {
            Hayat h = new Hayat();
            h.RngTohum = tohum;
            h.RngDurum = tohum;
            return new Rastgele(h);
        }

        public uint SonrakiUint()
        {
            unchecked
            {
                hayat.RngDurum += 0x6D2B79F5u;
                uint t = hayat.RngDurum;
                t = (t ^ (t >> 15)) * (t | 1u);
                t ^= t + (t ^ (t >> 7)) * (t | 61u);
                return t ^ (t >> 14);
            }
        }

        /// <summary>[0, 1) aralığında sayı.</summary>
        public double Sonraki()
        {
            return SonrakiUint() / 4294967296.0;
        }

        /// <summary>enAz ve enCok dahil tam sayı.</summary>
        public int Aralik(int enAz, int enCok)
        {
            if (enCok <= enAz) return enAz;
            return enAz + (int)(Sonraki() * (enCok - enAz + 1));
        }

        /// <summary>Yüzde olasılıkla true.</summary>
        public bool Olasilik(double yuzde)
        {
            return Sonraki() * 100.0 < yuzde;
        }

        public T Sec<T>(IList<T> liste)
        {
            return liste[Aralik(0, liste.Count - 1)];
        }

        /// <summary>Ağırlıklara göre bir sıra numarası seçer.</summary>
        public int Agirlikli(IList<int> agirliklar)
        {
            double toplam = 0;
            for (int i = 0; i < agirliklar.Count; i++)
            {
                if (agirliklar[i] > 0) toplam += agirliklar[i];
            }
            if (toplam <= 0) return 0;

            double x = Sonraki() * toplam;
            double birikim = 0;
            for (int i = 0; i < agirliklar.Count; i++)
            {
                if (agirliklar[i] <= 0) continue;
                birikim += agirliklar[i];
                if (x < birikim) return i;
            }
            return agirliklar.Count - 1;
        }
    }
}
