using System;
using System.Collections.Generic;

namespace Omur
{
    [Serializable]
    public class GunlukSatiri
    {
        public int Yas;
        public string Metin = "";
    }

    [Serializable]
    public class OlayKaydi
    {
        public string Id = "";
        public int Yas;
        public bool Kalici;
    }

    /// <summary>
    /// Tek bir hayatın tüm durumu. JSON olarak kaydedilir (Dictionary yok; JsonUtility uyumlu).
    /// </summary>
    [Serializable]
    public class Hayat
    {
        public int Surum = Sabit.KayitSurumu;

        // Kimlik
        public string Ad = "";
        public string Soyad = "";
        public string Cinsiyet = "Kadın";
        public string Il = "";
        public int IlSinifi;        // 0 büyükşehir, 1 orta, 2 küçük
        public int DogumYili = 2000;
        public int Yas;

        // Aile
        public int AileDuzeyi;      // 0 düşük, 1 orta, 2 yüksek
        public string AnneAdi = "";
        public string BabaAdi = "";
        public string AnneMeslek = "";
        public string BabaMeslek = "";
        public int KardesSayisi;

        // İstatistikler (0-100)
        public int Saglik = 60;
        public int Mutluluk = 70;
        public int Zeka = 50;
        public int Gorunum = 50;
        public int Sosyallik = 50;
        public int Disiplin = 50;
        public int Sans = 50;
        public int Itibar = 50;
        public int Stres = 10;
        public int Arananlik;
        public long Para;

        // Yıllık eylemler
        public int KalanEylem;
        public List<string> YilEylem = new List<string>();
        public int[] YilBasiStat = new int[IstatBilgi.Adet];
        public long YilBasiPara;

        // Yaşam durumu
        public bool Yasiyor = true;
        public string OlumNedeni = "";
        public int OlumYasi;

        // Hafıza
        public List<string> Bayraklar = new List<string>();
        public List<GunlukSatiri> Gunluk = new List<GunlukSatiri>();
        public bool GunlukKirpildi;
        public List<OlayKaydi> OlayGecmisi = new List<OlayKaydi>();
        public string ZincirOlay = "";
        public int ToplamOlay;

        // Rastgelelik: tohum ve geçerli durum kayıtla birlikte saklanır
        public uint RngTohum;
        public uint RngDurum;

        public int Yil
        {
            get { return DogumYili + Yas; }
        }

        public string TamAd
        {
            get { return Ad + " " + Soyad; }
        }

        public int Al(Istat i)
        {
            switch (i)
            {
                case Istat.Saglik: return Saglik;
                case Istat.Mutluluk: return Mutluluk;
                case Istat.Zeka: return Zeka;
                case Istat.Gorunum: return Gorunum;
                case Istat.Sosyallik: return Sosyallik;
                case Istat.Disiplin: return Disiplin;
                case Istat.Sans: return Sans;
                case Istat.Itibar: return Itibar;
                case Istat.Stres: return Stres;
                default: return Arananlik;
            }
        }

        public void Ayarla(Istat i, int deger)
        {
            if (deger < 0) deger = 0;
            if (deger > 100) deger = 100;
            switch (i)
            {
                case Istat.Saglik: Saglik = deger; break;
                case Istat.Mutluluk: Mutluluk = deger; break;
                case Istat.Zeka: Zeka = deger; break;
                case Istat.Gorunum: Gorunum = deger; break;
                case Istat.Sosyallik: Sosyallik = deger; break;
                case Istat.Disiplin: Disiplin = deger; break;
                case Istat.Sans: Sans = deger; break;
                case Istat.Itibar: Itibar = deger; break;
                case Istat.Stres: Stres = deger; break;
                default: Arananlik = deger; break;
            }
        }

        public void Ekle(Istat i, int fark)
        {
            Ayarla(i, Al(i) + fark);
        }

        public bool BayrakVar(string bayrak)
        {
            return Bayraklar.Contains(bayrak);
        }

        public void BayrakEkle(string bayrak)
        {
            if (!Bayraklar.Contains(bayrak)) Bayraklar.Add(bayrak);
        }

        public void BayrakSil(string bayrak)
        {
            Bayraklar.Remove(bayrak);
        }

        public void YilBasiniKaydet()
        {
            if (YilBasiStat == null || YilBasiStat.Length != IstatBilgi.Adet)
            {
                YilBasiStat = new int[IstatBilgi.Adet];
            }
            for (int i = 0; i < IstatBilgi.Adet; i++)
            {
                YilBasiStat[i] = Al((Istat)i);
            }
            YilBasiPara = Para;
        }

        /// <summary>Dışarıdan gelen (içe aktarılan) kaydı güvenli hale getirir.</summary>
        public void Dogrula()
        {
            for (int i = 0; i < IstatBilgi.Adet; i++)
            {
                Ayarla((Istat)i, Al((Istat)i));
            }
            if (Para < 0) Para = 0;
            if (Yas < 0) Yas = 0;
            if (Yas > Sabit.EnYuksekYas) Yas = Sabit.EnYuksekYas;
            if (KalanEylem < 0) KalanEylem = 0;
            if (Ad == null) Ad = "";
            if (Soyad == null) Soyad = "";
            if (Il == null) Il = "";
            if (OlumNedeni == null) OlumNedeni = "";
            if (ZincirOlay == null) ZincirOlay = "";
            if (YilEylem == null) YilEylem = new List<string>();
            if (Bayraklar == null) Bayraklar = new List<string>();
            if (Gunluk == null) Gunluk = new List<GunlukSatiri>();
            if (OlayGecmisi == null) OlayGecmisi = new List<OlayKaydi>();
            if (YilBasiStat == null || YilBasiStat.Length != IstatBilgi.Adet) YilBasiKaydet();
        }
    }
}
