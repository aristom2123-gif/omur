using System;
using System.Collections.Generic;
using System.Text;

namespace Omur
{
    /// <summary>Yıl sonu raporu: o yılın istatistik ve para değişimi ile önemli satırlar.</summary>
    public sealed class YilRaporu
    {
        public int Yas;
        public int Yil;
        public int[] StatFarki = new int[IstatBilgi.Adet];
        public long ParaFarki;
        public List<string> Satirlar = new List<string>();
        public bool Oldu;
    }

    public sealed class SecimSonucu
    {
        public bool Yapildi = true;
        public string Metin = "";
        public string EtkiOzeti = "";
        public bool SansVar;
        public int Yuzde;
        public bool Basari = true;
        public bool Kritik;
        public bool Oldu;
    }

    /// <summary>
    /// Oyun motoru: arayüzden bağımsızdır. Unity dışında da çalışır (Tools/Simulasyon).
    /// Yıl akışı: YilBaslat → (SonrakiSecimliOlay → Sec)* → YilBitir.
    /// </summary>
    public sealed class OyunMotoru
    {
        public Hayat H { get; private set; }
        public Olay GecerliOlay { get; private set; }
        public string GecerliMetin { get; private set; }

        private readonly Rastgele R;
        private readonly Queue<Olay> kuyruk = new Queue<Olay>();
        private YilRaporu rapor = new YilRaporu();

        private static readonly string[] SakinYilMetinleri =
        {
            "Sakin bir yıl geçti; büyük olay yoktu ama küçük mutluluklar eksik olmadı.",
            "Bu yıl rutin işlerle geçti; zaman ne kadar hızlı akıyor.",
            "Önemli bir şey olmadı; bazen en iyi yıllar böyledir.",
            "Yıl sessizce geçti; mevsimler değişti, sen de biraz değiştin."
        };

        public OyunMotoru(Hayat h)
        {
            H = h;
            H.Dogrula();
            R = new Rastgele(H);
        }

        // ------------------------------------------------------------------
        // Doğum
        // ------------------------------------------------------------------

        /// <summary>Yeni bir hayat başlatır. cinsiyetSecim: "Erkek", "Kadın" ya da başka bir şey (rastgele). ilSecim null ise rastgele.</summary>
        public static Hayat YeniHayat(string ad, string soyad, string cinsiyetSecim, string ilSecim, uint tohum, int baslangicYili)
        {
            Hayat h = new Hayat();
            h.RngTohum = tohum;
            h.RngDurum = tohum;
            Rastgele r = new Rastgele(h);

            h.Ad = Tr.AdTemizle(ad, 20);
            h.Soyad = Tr.AdTemizle(soyad, 20);
            if (h.Ad.Length == 0) h.Ad = "Adsız";
            if (h.Soyad.Length == 0) h.Soyad = "Soyadsız";

            if (cinsiyetSecim == "Erkek" || cinsiyetSecim == "Kadın") h.Cinsiyet = cinsiyetSecim;
            else h.Cinsiyet = r.Olasilik(50) ? "Erkek" : "Kadın";

            IlBilgi il = string.IsNullOrEmpty(ilSecim) ? null : Isimler.IlBul(ilSecim);
            if (il == null) il = r.Sec(Isimler.Iller);
            h.Il = il.Ad;
            h.IlSinifi = il.Sinif;

            h.AileDuzeyi = r.Agirlikli(new int[] { 30, 55, 15 });
            string[] meslekler = h.AileDuzeyi == 0 ? Isimler.MeslekDusuk : (h.AileDuzeyi == 1 ? Isimler.MeslekOrta : Isimler.MeslekYuksek);
            h.AnneAdi = r.Sec(Isimler.KadinAdlari);
            h.BabaAdi = r.Sec(Isimler.ErkekAdlari);
            h.BabaMeslek = r.Sec(meslekler);
            h.AnneMeslek = r.Olasilik(h.AileDuzeyi == 2 ? 15 : 35) ? "ev hanımı" : r.Sec(meslekler);
            h.KardesSayisi = r.Agirlikli(new int[] { 30, 40, 20, 10 });

            h.Saglik = EbeveynliDeger(r, 50, 80);
            h.Zeka = EbeveynliDeger(r, 40, 75);
            h.Gorunum = EbeveynliDeger(r, 40, 75);
            h.Sosyallik = EbeveynliDeger(r, 40, 75);
            h.Disiplin = EbeveynliDeger(r, 40, 75);
            h.Sans = r.Aralik(30, 70);
            h.Mutluluk = 70;
            h.Stres = 10;
            h.Itibar = 50;
            h.Arananlik = 0;
            h.Para = 0;

            bool hassas = r.Olasilik(8);
            if (hassas) h.Saglik = Math.Max(10, h.Saglik - 12);

            h.DogumYili = baslangicYili;
            h.Yas = 0;
            h.KalanEylem = 0;

            string dogum = h.TamAd + ", " + Tr.BulunmaEki(h.Il) + " dünyaya geldi.";
            if (hassas) dogum += " Biraz erken geldi ve ilk günlerini hastanede geçirdi.";
            h.Gunluk.Add(new GunlukSatiri { Yas = 0, Metin = dogum });

            string kardes = h.KardesSayisi == 0 ? "Ailenin tek çocuğusun." : (h.KardesSayisi == 1 ? "Bir kardeşin var." : h.KardesSayisi + " kardeşin var.");
            string durum = h.AileDuzeyi == 0 ? "sınırlı imkânlarla geçiniyor" : (h.AileDuzeyi == 1 ? "orta halli" : "rahat bir yaşam sürüyor");
            h.Gunluk.Add(new GunlukSatiri
            {
                Yas = 0,
                Metin = "Annen " + h.AnneAdi + " (" + h.AnneMeslek + "), baban " + h.BabaAdi + " (" + h.BabaMeslek + "). " + kardes + " Aile maddi olarak " + durum + "."
            });

            h.YilBasiniKaydet();
            return h;
        }

        /// <summary>Anne-baba ortalamasına yakın (en fazla ±15 sapmalı) başlangıç değeri.</summary>
        private static int EbeveynliDeger(Rastgele r, int enAz, int enCok)
        {
            int anne = r.Aralik(enAz, enCok);
            int baba = r.Aralik(enAz, enCok);
            int ortalama = (anne + baba) / 2;
            int sapma = r.Aralik(-15, 15);
            return Math.Max(10, Math.Min(95, ortalama + sapma));
        }

        // ------------------------------------------------------------------
        // Eylemler
        // ------------------------------------------------------------------

        public int EylemHakkiHesapla()
        {
            int yas = H.Yas;
            int hak;
            if (yas < 6) hak = 0;
            else if (yas < 18) hak = 2;
            else if (yas < 65) hak = 3;
            else hak = 2;
            if (hak > 1 && (H.Stres > 85 || H.Saglik < 25)) hak--;
            return hak;
        }

        public long EylemUcreti(Eylem e)
        {
            return H.Yas >= Sabit.ResitlikYasi ? e.Ucret : 0;
        }

        public List<Eylem> UygunEylemler()
        {
            List<Eylem> liste = new List<Eylem>();
            for (int i = 0; i < Eylemler.Liste.Count; i++)
            {
                Eylem e = Eylemler.Liste[i];
                if (H.Yas >= e.MinYas && H.Yas <= e.MaxYas) liste.Add(e);
            }
            return liste;
        }

        /// <summary>Eylem yapılabilir mi? Yapılamıyorsa nedeni döner.</summary>
        public bool EylemYapilabilir(Eylem e, out string neden)
        {
            neden = "";
            if (!H.Yasiyor) { neden = "Hayat sona erdi."; return false; }
            if (H.KalanEylem <= 0) { neden = "Bu yıl için eylem hakkın kalmadı."; return false; }
            if (H.Yas < e.MinYas || H.Yas > e.MaxYas) { neden = "Bu yaşta yapılamaz."; return false; }
            if (EylemUcreti(e) > H.Para) { neden = "Yeterli paran yok."; return false; }
            return true;
        }

        public SecimSonucu EylemYap(string id)
        {
            SecimSonucu sonuc = new SecimSonucu();
            Eylem e = Eylemler.Bul(id);
            string neden;
            if (e == null || !EylemYapilabilir(e, out neden))
            {
                sonuc.Yapildi = false;
                sonuc.Metin = e == null ? "Bilinmeyen eylem." : "Bu eylem şu an yapılamaz.";
                return sonuc;
            }

            long ucret = EylemUcreti(e);
            H.Para -= ucret;
            H.KalanEylem--;
            H.YilEylem.Add(e.Ad);

            Sonuc secilen;
            if (e.Sans == null)
            {
                secilen = e.Basari;
            }
            else
            {
                SansSonuc z = SansMotoru.Zar(H, R, e.Sans, 0);
                sonuc.SansVar = true;
                sonuc.Yuzde = z.Yuzde;
                sonuc.Basari = z.Basari;
                secilen = z.Basari ? e.Basari : e.Basarisiz;
            }

            secilen.Etki.Uygula(H);
            sonuc.Metin = secilen.Metin;
            sonuc.EtkiOzeti = OzetEkle(secilen.Etki.Ozet(), ucret);
            if (H.Saglik <= 0) Oldur("Sağlık sorunları", null);
            sonuc.Oldu = !H.Yasiyor;
            return sonuc;
        }

        // ------------------------------------------------------------------
        // Yıl akışı
        // ------------------------------------------------------------------

        /// <summary>'Yaşlan'a basılınca: otomatik hesaplar, ölüm kontrolü ve olayların seçimi.</summary>
        public YilRaporu YilBaslat()
        {
            rapor = new YilRaporu();
            rapor.Yas = H.Yas;
            rapor.Yil = H.Yil;
            kuyruk.Clear();
            GecerliOlay = null;
            GecerliMetin = "";

            OtomatikYil();
            if (!H.Yasiyor)
            {
                rapor.Oldu = true;
                return rapor;
            }

            OlaylariSec();
            return rapor;
        }

        /// <summary>Sıradaki seçimli olayı döner. Seçeneksiz olaylar kendiliğinden uygulanır. Kalmadıysa null.</summary>
        public Olay SonrakiSecimliOlay()
        {
            GecerliOlay = null;
            GecerliMetin = "";
            while (kuyruk.Count > 0 && H.Yasiyor)
            {
                Olay o = kuyruk.Dequeue();
                if (o.Secenekler.Count == 0)
                {
                    OtomatikUygula(o);
                    continue;
                }
                GecerliOlay = o;
                GecerliMetin = Doldur(R.Sec(o.Metin));
                return o;
            }
            return null;
        }

        public bool SecenekKullanilabilir(Secenek s)
        {
            if (s.Ucret > H.Para) return false;
            if (s.OnKosul != null && !s.OnKosul(H)) return false;
            return true;
        }

        /// <summary>Geçerli olayın seçeneğini uygular.</summary>
        public SecimSonucu Sec(int index)
        {
            SecimSonucu sonuc = new SecimSonucu();
            Olay o = GecerliOlay;
            if (o == null || index < 0 || index >= o.Secenekler.Count)
            {
                sonuc.Yapildi = false;
                return sonuc;
            }
            Secenek s = o.Secenekler[index];
            if (!SecenekKullanilabilir(s))
            {
                sonuc.Yapildi = false;
                sonuc.Metin = "Bu seçenek şu an kullanılamıyor.";
                return sonuc;
            }

            H.Para -= s.Ucret;

            Sonuc secilen;
            if (s.Sans == null)
            {
                secilen = s.Basari;
            }
            else
            {
                SansSonuc z = SansMotoru.Zar(H, R, s.Sans, 0);
                sonuc.SansVar = true;
                sonuc.Yuzde = z.Yuzde;
                sonuc.Basari = z.Basari;
                if (z.Basari)
                {
                    bool kritik = z.Kritik && s.KritikBasari != null;
                    secilen = kritik ? s.KritikBasari : s.Basari;
                    sonuc.Kritik = kritik;
                }
                else
                {
                    bool kritik = z.Kritik && s.KritikBasarisiz != null;
                    secilen = kritik ? s.KritikBasarisiz : s.Basarisiz;
                    sonuc.Kritik = kritik;
                }
            }

            secilen.Etki.Uygula(H);
            sonuc.Metin = Doldur(secilen.Metin);
            sonuc.EtkiOzeti = OzetEkle(secilen.Etki.Ozet(), s.Ucret);

            Gunluge(sonuc.Metin);
            rapor.Satirlar.Add(sonuc.Metin);

            if (!string.IsNullOrEmpty(secilen.Etki.Olum)) Oldur(secilen.Etki.Olum, rapor);
            else if (H.Saglik <= 0) Oldur("Sağlık sorunları", rapor);

            sonuc.Oldu = !H.Yasiyor;
            GecerliOlay = null;
            return sonuc;
        }

        /// <summary>Olaylar bitince: yıl raporu hazırlanır, yaş bir artar, yeni yılın eylem hakkı verilir.</summary>
        public YilRaporu YilBitir()
        {
            YilRaporu rap = rapor;

            if (H.YilEylem.Count > 0)
            {
                string eylemler = "Bu yıl yaptıkların: " + string.Join(", ", H.YilEylem.ToArray()) + ".";
                Gunluge(eylemler);
            }
            if (rap.Satirlar.Count == 0)
            {
                string sakin = R.Sec(SakinYilMetinleri);
                Gunluge(sakin);
                rap.Satirlar.Add(sakin);
            }

            for (int i = 0; i < IstatBilgi.Adet; i++)
            {
                rap.StatFarki[i] = H.Al((Istat)i) - H.YilBasiStat[i];
            }
            rap.ParaFarki = H.Para - H.YilBasiPara;

            H.Yas++;
            H.KalanEylem = EylemHakkiHesapla();
            H.YilEylem.Clear();
            GecmisiTemizle();
            H.YilBasiniKaydet();
            rapor = new YilRaporu();
            return rap;
        }

        // ------------------------------------------------------------------
        // İç işleyiş
        // ------------------------------------------------------------------

        private void OtomatikYil()
        {
            int yas = H.Yas;

            if (H.Stres > 85)
            {
                H.Ekle(Istat.Saglik, -3);
                H.Ekle(Istat.Mutluluk, -2);
            }
            else if (H.Stres > 70)
            {
                H.Ekle(Istat.Saglik, -2);
                H.Ekle(Istat.Mutluluk, -2);
            }
            else if (H.Stres < 30)
            {
                H.Ekle(Istat.Mutluluk, 1);
            }

            H.Ayarla(Istat.Stres, H.Stres + (int)Math.Round((35 - H.Stres) * 0.2));
            H.Ayarla(Istat.Mutluluk, H.Mutluluk + (int)Math.Round((55 - H.Mutluluk) * 0.1));

            if (yas <= 17)
            {
                if (H.Saglik < 90) H.Ekle(Istat.Saglik, R.Aralik(0, 1));
                if (H.Zeka < 90 && R.Olasilik(50)) H.Ekle(Istat.Zeka, 1);
            }
            else if (yas <= 39)
            {
                if (R.Olasilik(25)) H.Ekle(Istat.Saglik, -1);
            }
            else if (yas <= 59)
            {
                H.Ekle(Istat.Saglik, R.Aralik(-1, 0));
            }
            else if (yas <= 74)
            {
                H.Ekle(Istat.Saglik, R.Aralik(-3, -1));
            }
            else
            {
                H.Ekle(Istat.Saglik, R.Aralik(-4, -2));
            }

            if (yas >= 65 && R.Olasilik(40)) H.Ekle(Istat.Zeka, -1);
            if (yas >= 60) H.Ekle(Istat.Gorunum, -1);
            else if (yas >= 35 && R.Olasilik(50)) H.Ekle(Istat.Gorunum, -1);
            if (yas >= 70 && R.Olasilik(30)) H.Ekle(Istat.Sosyallik, -1);

            H.Ayarla(Istat.Itibar, H.Itibar + Math.Sign(50 - H.Itibar));
            if (H.Arananlik > 0) H.Ekle(Istat.Arananlik, -2);

            OlumKontrol();
        }

        /// <summary>Yaşa göre yıllık ölüm olasılığı (sadeleştirilmiş tablo).</summary>
        public static double OlumOrani(int yas)
        {
            if (yas <= 0) return 0.010;
            if (yas <= 4) return 0.0008;
            if (yas <= 14) return 0.0003;
            if (yas <= 24) return 0.0007;
            if (yas <= 34) return 0.0009;
            if (yas <= 44) return 0.0016;
            if (yas <= 54) return 0.0040;
            if (yas <= 64) return 0.0100;
            if (yas <= 74) return 0.0250;
            if (yas <= 84) return 0.0650;
            if (yas <= 94) return 0.1600;
            if (yas <= 104) return 0.3000;
            return 0.6000;
        }

        /// <summary>Sağlık yüksekse risk azalır, düşükse artar (0.4x - 3x).</summary>
        public static double SaglikCarpani(int saglik)
        {
            double f = 1.0 + (50 - saglik) / 40.0;
            if (f < 0.4) f = 0.4;
            if (f > 3.0) f = 3.0;
            return f;
        }

        private void OlumKontrol()
        {
            string neden = null;
            if (H.Saglik <= 0)
            {
                neden = "Uzun süren sağlık sorunları";
            }
            else if (H.Yas >= Sabit.EnYuksekYas)
            {
                neden = "Yaşlılığa bağlı sağlık sorunları";
            }
            else
            {
                double p = OlumOrani(H.Yas) * SaglikCarpani(H.Saglik);
                if (R.Sonraki() < p) neden = OlumNedeniSec(H.Yas);
            }
            if (neden != null) Oldur(neden, rapor);
        }

        private string OlumNedeniSec(int yas)
        {
            string[] secenekler;
            if (yas == 0) secenekler = new string[] { "Doğumdan kısa süre sonra ortaya çıkan sağlık sorunları" };
            else if (yas <= 17) secenekler = new string[] { "Ani bir hastalık", "Bir kaza" };
            else if (yas <= 49) secenekler = new string[] { "Bir kaza", "Ani bir hastalık", "Kalp rahatsızlığı" };
            else if (yas <= 74) secenekler = new string[] { "Kalp rahatsızlığı", "Uzun süren bir hastalık", "Bir kaza" };
            else secenekler = new string[] { "Yaşlılığa bağlı sağlık sorunları", "Kalp yetmezliği", "Uykusunda, sessizce" };
            return R.Sec(secenekler);
        }

        private void Oldur(string neden, YilRaporu rap)
        {
            if (!H.Yasiyor) return;
            if (neden.Length > 0) neden = Tr.Buyuk(neden[0]) + neden.Substring(1);
            H.Yasiyor = false;
            H.OlumNedeni = neden;
            H.OlumYasi = H.Yas;
            string satir = H.TamAd + ", " + H.Yas + " yaşında hayatını kaybetti. Sebep: " + neden + ".";
            Gunluge(satir);
            if (rap != null)
            {
                rap.Oldu = true;
                rap.Satirlar.Add(satir);
            }
        }

        private void OlaylariSec()
        {
            kuyruk.Clear();
            int yas = H.Yas;
            List<Olay> tum = OlayHavuzu.Tum;
            List<Olay> zorunlular = new List<Olay>();
            List<Olay> adaylar = new List<Olay>();

            for (int i = 0; i < tum.Count; i++)
            {
                Olay o = tum[i];
                if (!UygunMu(o)) continue;
                if (o.Zorunlu) zorunlular.Add(o);
                else adaylar.Add(o);
            }

            if (!string.IsNullOrEmpty(H.ZincirOlay))
            {
                Olay z = OlayHavuzu.Bul(H.ZincirOlay);
                H.ZincirOlay = "";
                if (z != null) Siraya(z);
            }
            for (int i = 0; i < zorunlular.Count; i++) Siraya(zorunlular[i]);

            int n;
            if (yas <= 5) n = R.Aralik(1, 2);
            else n = R.Agirlikli(new int[] { 10, 35, 35, 15, 5 });
            int izinli = Sabit.YillikEnCokOlay - kuyruk.Count;
            if (n > izinli) n = izinli;

            for (int k = 0; k < n && adaylar.Count > 0; k++)
            {
                List<int> agirliklar = new List<int>();
                for (int i = 0; i < adaylar.Count; i++) agirliklar.Add(adaylar[i].Agirlik);
                int idx = R.Agirlikli(agirliklar);
                Olay secilen = adaylar[idx];
                adaylar.RemoveAt(idx);
                Siraya(secilen);
            }
        }

        private void Siraya(Olay o)
        {
            kuyruk.Enqueue(o);
            OlayKaydi kayit = new OlayKaydi();
            kayit.Id = o.Id;
            kayit.Yas = H.Yas;
            kayit.Kalici = o.TekSefer;
            H.OlayGecmisi.Add(kayit);
            H.ToplamOlay++;
        }

        private bool UygunMu(Olay o)
        {
            if (o.Agirlik <= 0 && !o.Zorunlu) return false;
            if (H.Yas < o.MinYas || H.Yas > o.MaxYas) return false;
            if (o.Kosul != null && !o.Kosul(H)) return false;
            for (int i = 0; i < H.OlayGecmisi.Count; i++)
            {
                OlayKaydi k = H.OlayGecmisi[i];
                if (k.Id != o.Id) continue;
                if (o.TekSefer) return false;
                if (H.Yas - k.Yas < Sabit.OlayTekrarYili) return false;
            }
            return true;
        }

        private void GecmisiTemizle()
        {
            for (int i = H.OlayGecmisi.Count - 1; i >= 0; i--)
            {
                OlayKaydi k = H.OlayGecmisi[i];
                if (!k.Kalici && H.Yas - k.Yas >= Sabit.OlayTekrarYili) H.OlayGecmisi.RemoveAt(i);
            }
        }

        private void OtomatikUygula(Olay o)
        {
            string metin = Doldur(R.Sec(o.Metin));
            o.Otomatik.Etki.Uygula(H);
            Gunluge(metin);
            rapor.Satirlar.Add(metin);
            if (!string.IsNullOrEmpty(o.Otomatik.Etki.Olum)) Oldur(o.Otomatik.Etki.Olum, rapor);
            else if (H.Saglik <= 0) Oldur("Sağlık sorunları", rapor);
        }

        private void Gunluge(string metin)
        {
            GunlukSatiri s = new GunlukSatiri();
            s.Yas = H.Yas;
            s.Metin = metin;
            H.Gunluk.Add(s);
            if (H.Gunluk.Count > Sabit.GunlukSiniri)
            {
                H.Gunluk.RemoveRange(0, Sabit.GunlukKirpma);
                H.GunlukKirpildi = true;
            }
        }

        public string Doldur(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("{ad}", H.Ad)
                    .Replace("{soyad}", H.Soyad)
                    .Replace("{il}", H.Il)
                    .Replace("{anne}", H.AnneAdi)
                    .Replace("{baba}", H.BabaAdi);
        }

        private static string OzetEkle(string ozet, long ucret)
        {
            if (ucret <= 0) return ozet;
            string u = "Ücret -" + Tr.TL(ucret);
            return ozet.Length > 0 ? ozet + "  ·  " + u : u;
        }

        // ------------------------------------------------------------------
        // Hayatın özeti
        // ------------------------------------------------------------------

        /// <summary>Basit hayat puanı (denge çalışmasında ayarlanacak).</summary>
        public static int HayatPuani(Hayat h)
        {
            long para = Math.Min(500, h.Para / 10000);
            return h.Yas * 8 + h.Mutluluk * 2 + h.Itibar + (int)para + h.ToplamOlay;
        }

        public List<string> OlumOzeti()
        {
            List<string> satirlar = new List<string>();
            satirlar.Add(H.TamAd + ", " + Tr.BulunmaEki(H.Il) + " doğdu ve " + H.OlumYasi + " yaşında hayata veda etti.");
            if (!string.IsNullOrEmpty(H.OlumNedeni)) satirlar.Add("Sebep: " + H.OlumNedeni + ".");
            satirlar.Add("Yaşadığı olay sayısı: " + H.ToplamOlay + ".");
            satirlar.Add("Son durumu: Sağlık " + H.Saglik + ", Mutluluk " + H.Mutluluk + ", Zekâ " + H.Zeka
                + ", Sosyallik " + H.Sosyallik + ", İtibar " + H.Itibar + ", Para " + Tr.TL(H.Para) + ".");
            satirlar.Add("Hayat puanı: " + HayatPuani(H) + ".");
            return satirlar;
        }
    }
}
