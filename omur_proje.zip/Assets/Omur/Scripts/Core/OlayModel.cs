using System;
using System.Collections.Generic;

namespace Omur
{
    public enum HavuzTuru
    {
        Cocukluk,
        Okul,
        Genclik,
        Is,
        Suc,
        Hukuk,
        Hapis,
        Hayvan,
        Saglik,
        Ekonomi,
        Aile,
        Genel
    }

    public static class HavuzAdi
    {
        public static string Ad(HavuzTuru t)
        {
            switch (t)
            {
                case HavuzTuru.Cocukluk: return "Çocukluk";
                case HavuzTuru.Okul: return "Okul";
                case HavuzTuru.Genclik: return "Gençlik";
                case HavuzTuru.Is: return "İş";
                case HavuzTuru.Suc: return "Karanlık Taraf";
                case HavuzTuru.Hukuk: return "Hukuk";
                case HavuzTuru.Hapis: return "Hapishane";
                case HavuzTuru.Hayvan: return "Hayvanlar";
                case HavuzTuru.Saglik: return "Sağlık";
                case HavuzTuru.Ekonomi: return "Ekonomi";
                case HavuzTuru.Aile: return "Aile";
                default: return "Hayat";
            }
        }
    }

    /// <summary>Bir seçeneğin (ya da otomatik olayın) sonucu: metin + etki.</summary>
    public sealed class Sonuc
    {
        public string Metin = "";
        public Etki Etki = new Etki();
    }

    public sealed class Secenek
    {
        public string Etiket = "";
        public Func<Hayat, bool> OnKosul;
        public long Ucret;
        public SansTanim Sans;                 // null ise şanssız, doğrudan Basari
        public Sonuc Basari;
        public Sonuc Basarisiz;
        public Sonuc KritikBasari;             // yoksa Basari kullanılır
        public Sonuc KritikBasarisiz;          // yoksa Basarisiz kullanılır

        public Secenek UcretEkle(long ucret)
        {
            Ucret = ucret;
            return this;
        }

        public Secenek Sart(Func<Hayat, bool> kosul)
        {
            OnKosul = kosul;
            return this;
        }

        public Secenek Kritik(Sonuc kritikBasari, Sonuc kritikBasarisiz)
        {
            KritikBasari = kritikBasari;
            KritikBasarisiz = kritikBasarisiz;
            return this;
        }
    }

    public sealed class Olay
    {
        public string Id = "";
        public HavuzTuru Havuz = HavuzTuru.Genel;
        public int MinYas;
        public int MaxYas = 120;
        public Func<Hayat, bool> Kosul;
        public int Agirlik = 10;               // 0 ise rastgele seçilmez (yalnızca zincir)
        public bool TekSefer;
        public bool Zorunlu;                   // uygun yaştaysa her zaman çıkar
        public string[] Metin = new string[0];  // en az 2-3 varyasyon tercih edilir
        public List<Secenek> Secenekler = new List<Secenek>();
        public Sonuc Otomatik;                 // seçeneksiz (otomatik) olaylar için

        public Olay Bir()
        {
            TekSefer = true;
            return this;
        }

        public Olay Agir(int agirlik)
        {
            Agirlik = agirlik;
            return this;
        }

        public Olay Sart(Func<Hayat, bool> kosul)
        {
            Kosul = kosul;
            return this;
        }

        public Olay Mutlaka()
        {
            Zorunlu = true;
            return this;
        }
    }

    /// <summary>Olay yazmak için kısa yardımcılar (veri dosyalarını sade tutar).</summary>
    public static class Y
    {
        public static Sonuc Sn(string metin, string etki)
        {
            Sonuc s = new Sonuc();
            s.Metin = metin;
            s.Etki = Etki.Cozumle(etki);
            return s;
        }

        /// <summary>Seçeneksiz olay: metin günlüğe yazılır, etki kendiliğinden uygulanır.</summary>
        public static Olay Oto(string id, HavuzTuru havuz, int minYas, int maxYas, string etki, params string[] metinler)
        {
            Olay o = new Olay();
            o.Id = id;
            o.Havuz = havuz;
            o.MinYas = minYas;
            o.MaxYas = maxYas;
            o.Metin = metinler;
            o.Otomatik = new Sonuc();
            o.Otomatik.Etki = Etki.Cozumle(etki);
            return o;
        }

        /// <summary>Seçimli olay. Metin varyasyonları '|' ile ayrılır.</summary>
        public static Olay Karar(string id, HavuzTuru havuz, int minYas, int maxYas, string metin, params Secenek[] secenekler)
        {
            Olay o = new Olay();
            o.Id = id;
            o.Havuz = havuz;
            o.MinYas = minYas;
            o.MaxYas = maxYas;
            o.Metin = metin.Split('|');
            o.Secenekler.AddRange(secenekler);
            return o;
        }

        /// <summary>Şanssız seçenek.</summary>
        public static Secenek Sec(string etiket, string sonucMetin, string etki)
        {
            Secenek s = new Secenek();
            s.Etiket = etiket;
            s.Basari = Sn(sonucMetin, etki);
            return s;
        }

        /// <summary>Şans zarına bağlı seçenek.</summary>
        public static Secenek SecSans(string etiket, int taban, string etkenler, Sonuc basari, Sonuc basarisiz)
        {
            Secenek s = new Secenek();
            s.Etiket = etiket;
            s.Sans = SansTanim.Olustur(taban, etkenler, 0);
            s.Basari = basari;
            s.Basarisiz = basarisiz;
            return s;
        }
    }
}
