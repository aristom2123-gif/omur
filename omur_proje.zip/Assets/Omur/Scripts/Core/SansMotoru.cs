using System;
using System.Collections.Generic;
using System.Globalization;

namespace Omur
{
    public struct Etken
    {
        public Istat Stat;
        public double Agirlik;

        public Etken(Istat stat, double agirlik)
        {
            Stat = stat;
            Agirlik = agirlik;
        }
    }

    /// <summary>Bir şans zarının tanımı: taban yüzde, istatistik etkenleri, sabit ek.</summary>
    public sealed class SansTanim
    {
        public int Taban;
        public Etken[] Etkenler = new Etken[0];
        public int Ek;

        /// <summary>etkenler örneği: "zek:0.4,dis:0.2"</summary>
        public static SansTanim Olustur(int taban, string etkenler, int ek)
        {
            SansTanim t = new SansTanim();
            t.Taban = taban;
            t.Ek = ek;
            if (!string.IsNullOrEmpty(etkenler))
            {
                string[] parcalar = etkenler.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                List<Etken> liste = new List<Etken>();
                for (int i = 0; i < parcalar.Length; i++)
                {
                    string[] kv = parcalar[i].Split(':');
                    Istat istat;
                    double agirlik;
                    if (kv.Length == 2
                        && IstatBilgi.KisaAdtanBul(kv[0].Trim(), out istat)
                        && double.TryParse(kv[1], NumberStyles.Float, CultureInfo.InvariantCulture, out agirlik))
                    {
                        liste.Add(new Etken(istat, agirlik));
                    }
                    else
                    {
                        Etki.Hatalar.Add("Şans etkeni okunamadı: '" + parcalar[i] + "'");
                    }
                }
                t.Etkenler = liste.ToArray();
            }
            return t;
        }
    }

    public struct SansSonuc
    {
        public int Yuzde;
        public bool Basari;
        public bool Kritik;
    }

    /// <summary>
    /// Tek şans fonksiyonu (5. bölüm). Şans gerektiren her şey buradan geçer.
    /// yüzde = taban + ek + (Şans-50)*0.1 + Σ ağırlık*(stat-50), her zaman %2-%98 arası.
    /// </summary>
    public static class SansMotoru
    {
        public static int Yuzde(Hayat h, SansTanim t, int ekEk)
        {
            double p = t.Taban + t.Ek + ekEk + (h.Sans - 50) * 0.1;
            for (int i = 0; i < t.Etkenler.Length; i++)
            {
                p += t.Etkenler[i].Agirlik * (h.Al(t.Etkenler[i].Stat) - 50);
            }
            if (p < Sabit.SansAlt) p = Sabit.SansAlt;
            if (p > Sabit.SansUst) p = Sabit.SansUst;
            return (int)Math.Round(p);
        }

        /// <summary>Her çağrı tam olarak iki rastgele sayı tüketir (deterministik akış için).</summary>
        public static SansSonuc Zar(Hayat h, Rastgele r, SansTanim t, int ekEk)
        {
            SansSonuc s = new SansSonuc();
            s.Yuzde = Yuzde(h, t, ekEk);
            s.Basari = r.Sonraki() * 100.0 < s.Yuzde;
            s.Kritik = r.Sonraki() * 100.0 < Sabit.KritikYuzde;
            return s;
        }

        public static string Etiket(int yuzde)
        {
            if (yuzde >= 65) return "Yüksek";
            if (yuzde >= 35) return "Orta";
            return "Düşük";
        }
    }
}
