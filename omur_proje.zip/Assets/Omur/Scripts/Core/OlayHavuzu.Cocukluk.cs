using System;
using System.Collections.Generic;

namespace Omur
{
    public static partial class OlayHavuzu
    {
        // Bebeklik ve çocukluk olayları (0-12 yaş) ve okul kilometre taşları.
        private static void CocuklukEkle(List<Olay> l)
        {
            // ---------- Bebeklik: seçeneksiz, kendiliğinden akan olaylar ----------
            l.Add(Y.Oto("ilk_gulus", HavuzTuru.Aile, 0, 0, "mut+2",
                "İlk kez gülümsedin; anne ile babanın yüzü aydınlandı.",
                "İlk gülücüğünü attın; evde bayram havası esti.").Bir().Mutlaka());

            l.Add(Y.Oto("ilk_adim", HavuzTuru.Aile, 1, 1, "sag+1 mut+3",
                "İlk adımlarını attın, sonra güzelce oturdun. Alkışlar yükseldi!",
                "Tutunarak ayağa kalktın, üç adım attın ve zafer çığlığı attın.").Bir().Mutlaka());

            l.Add(Y.Oto("ilk_kelime", HavuzTuru.Aile, 1, 2, "zek+2 sos+1",
                "İlk kelimen 'anne' oldu. Baba biraz alındı ama belli etmedi.",
                "İlk kelimen 'baba' oldu. Anne gurur duydu, biraz da kıskandı.",
                "İlk kelimen 'top' oldu. Kimse ne demek istediğini anlamadı ama herkes alkışladı.").Bir().Agir(30));

            l.Add(Y.Oto("nezle_bebek", HavuzTuru.Saglik, 0, 4, "sag-2 mut-1",
                "Bir kış nezle oldun; burnun akıp durdu ama çabucak atlattın.",
                "Hafif bir ateşle birkaç gün huysuzluk yaptın; kaynar çorbalarla toparlandın."));

            l.Add(Y.Oto("disler", HavuzTuru.Saglik, 1, 2, "mut-2",
                "İlk dişlerin çıktı; birkaç gece herkes uykusuz kaldı.",
                "Diş çıkarma günleri geldi; eline geçen her şeyi ısırdın.").Bir());

            l.Add(Y.Oto("bahce_oyun", HavuzTuru.Cocukluk, 2, 5, "mut+3 sos+2 sag+1",
                "Mahalle bahçesinde kumda saatlerce oynadın.",
                "Salıncakta uçtun, kaydıraktan iniş rekoru kırdın.",
                "Bahçedeki çocuklarla kum kalelerinden bir şehir kurdunuz."));

            l.Add(Y.Oto("cizgi_film", HavuzTuru.Cocukluk, 3, 5, "mut+2 zek+1",
                "Bir çizgi filmi yüzlerce kez izledin; repliklerini ezberledin.",
                "Ekran başında geçen saatlerin sonunda bütün şarkıları ezbere biliyordun."));

            l.Add(Y.Oto("kardes_oyun", HavuzTuru.Aile, 2, 8, "mut+3 sos+2",
                "Kardeşinle yastık savaşı yaptınız; biri vazoyu devirdi ama kimse suçu üstlenmedi.",
                "Kardeşinle battaniyeden kale yaptınız; tek giriş şartı şifre söylemekti.").Sart(d => d.KardesSayisi > 0));

            l.Add(Y.Oto("hayal_arkadas", HavuzTuru.Cocukluk, 3, 5, "zek+1 sos+1 mut+2",
                "Hayali bir arkadaşın oldu; ona sofrada yer bile ayırdın.",
                "Görünmez bir arkadaşınla uzun sohbetler ettin; kimse sana katılmadı ama kimse engel de olmadı.").Bir());

            l.Add(Y.Oto("buyukanne", HavuzTuru.Aile, 0, 6, "mut+3 sag+1",
                "Büyükanne ziyareti: elin kurabiye doluydu, kulağın nasihat.",
                "Büyükannenin kucağında masallar dinledin; hiçbirinde kurt kazanmadı."));

            l.Add(Y.Oto("yagmur", HavuzTuru.Cocukluk, 2, 8, "mut+3",
                "Yağmur dinince birikintilere zıpladın; botların sırılsıklam oldu.",
                "Yağmurda ıslanmaya doyamadın; eve gelince annen havluyla seni karşıladı."));

            l.Add(Y.Oto("anaokulu", HavuzTuru.Okul, 5, 5, "sos+3 zek+1",
                "Anaokulunun ilk gününde ağladın, ikinci gün bahçede bir arkadaş buldun.",
                "Anaokulunda boyama yaparken kâğıdın dışına çıkmanın özgürlüğünü keşfettin.").Bir().Mutlaka());

            l.Add(Y.Oto("ates_hastaligi", HavuzTuru.Saglik, 5, 12, "sag-3 mut-1",
                "Bir hafta ateşli yattın; çorba ve masallarla toparlandın.",
                "Mevsim geçişinde hastalandın; okuldan birkaç gün izinli sayıldın."));

            // ---------- Okul kilometre taşları (2. fazda gerçek okul sistemiyle değişecek) ----------
            l.Add(Y.Oto("ilkokul_basla", HavuzTuru.Okul, 6, 6, "zek+1 sos+2",
                "İlkokula başladın: yeni çanta, yeni defterler, yeni heyecanlar.",
                "İlkokulun ilk günü: sıra arkadaşın kim olacak diye endişeyle sınıfa girdin.").Bir().Mutlaka());

            l.Add(Y.Oto("ortaokul_basla", HavuzTuru.Okul, 10, 10, "sos+1 str+1",
                "Ortaokula geçtin; koridorlar büyüdü, sen de büyüdün.",
                "Ortaokulun ilk haftasında dolap kapaklarını açmayı öğrendin.").Bir().Mutlaka());

            l.Add(Y.Oto("lise_basla", HavuzTuru.Okul, 14, 14, "sos+2 dis+1",
                "Liseye başladın; artık kantinde stratejik pozisyon almak şart.",
                "Lise hayatı başladı; ödevler ağırlaştı, espriler keskinleşti.").Bir().Mutlaka());

            l.Add(Y.Oto("lise_bitis", HavuzTuru.Okul, 18, 18, "mut+3 str+2",
                "Liseyi bitirdin. Hayat sana 'Şimdi ne?' diye soruyor.",
                "Mezuniyet töreninde şapkalar havaya uçtu; seninki bir daha bulunamadı.").Bir().Mutlaka());

            // ---------- Çocukluk: seçimli olaylar ----------
            l.Add(Y.Karar("kedi_yavrusu", HavuzTuru.Cocukluk, 6, 12,
                "Okul dönüşü bir kedi yavrusu miyavlayarak peşine takıldı.|Yağmurlu bir akşam, apartman girişinde titreyen bir kedi yavrusu buldun.",
                Y.SecSans("Eve götür", 50, "sos:0.1,itb:0.1",
                    Y.Sn("Annen önce kaşlarını çattı, sonra yavruyu kucağına aldı. Evin yeni bir üyesi var!", "mut+7 sos+1 +b:kedi_sevgisi zincir:kedi_buyudu"),
                    Y.Sn("Annen izin vermedi; yavruyu komşuya götürdün. İçin biraz burkuldu ama emin ellerde.", "mut-3 +b:kedi_sevgisi")),
                Y.Sec("Su ve mama bırak", "Bir kap su ve biraz mama bırakıp uzaklaştın. Sokak kedilerinin de bir dostu var artık.", "mut+2 itb+1"),
                Y.Sec("Görmezden gel", "Arkana bakmadan yürüdün ama miyavlama kulağından gitmedi.", "mut-2 itb-1")).Bir().Agir(20));

            l.Add(Y.Oto("kedi_buyudu", HavuzTuru.Hayvan, 6, 25, "mut+3 str-2",
                "Yavru kedin büyüdü; artık koltuğun yarısı onun, kalan yarısı da ona ait sayılır.",
                "Kedin her sabah seni uyandırmayı görev edindi; alarm saati işsiz kaldı.").Agir(0));

            l.Add(Y.Karar("harclik", HavuzTuru.Cocukluk, 6, 12,
                "Haftalık harçlığını aldın. Cebinde küçük bir servet var.|Dedenin cebine tıkıştırdığı harçlığı sayıp durdun.",
                Y.Sec("Biriktir", "Kumbaranın sesi her hafta biraz daha dolgunlaştı.", "dis+2 para+300 mut+1"),
                Y.Sec("Şekerciye koş", "Şekerler harikaydı; dişlerinse pek memnun değil.", "mut+3 sag-1"),
                Y.Sec("Arkadaşlarına ikram et", "Herkes seni çok sevdi; cebin boşaldı ama gönlün doldu.", "sos+3 mut+2 itb+1")));

            l.Add(Y.Karar("agac_tirmanma", HavuzTuru.Cocukluk, 6, 13,
                "Mahalledeki yaşlı çınara tırmanmak için arkadaşların seni kışkırtıyor.|Arkadaşların en yüksek dala kimin çıkacağını tartışıyor; gözler sana döndü.",
                Y.SecSans("Tırman", 55, "sag:0.2,dis:0.1",
                    Y.Sn("Tepeden mahalleyi izledin; efsane oldun.", "mut+4 sos+3 itb+1"),
                    Y.Sn("Dal kırıldı; düştün ama sadece dizin sıyrıldı.", "sag-4 mut-2"))
                    .Kritik(Y.Sn("En tepeye çıktın; bütün mahalle seni alkışladı.", "mut+6 sos+4 itb+2"),
                            Y.Sn("Kötü düştün; bir ay alçıda kaldın.", "sag-10 mut-5")),
                Y.Sec("Aşağıdan izle", "Arkadaşlarını aşağıdan alkışladın; en azından kimse seni suçlayamaz.", "mut-1 sos-1")).Agir(15));

            l.Add(Y.Karar("odev_zor", HavuzTuru.Okul, 7, 13,
                "Matematik ödevinin son sorusu bir türlü çözülmüyor.|Fen ödevinde bir deney var ve sonuç kitaptakine hiç benzemiyor.",
                Y.SecSans("Sabırla çözmeye çalış", 45, "zek:0.3,dis:0.2",
                    Y.Sn("Sonunda çözdün! Defterin kenarına küçük bir zafer işareti çizdin.", "zek+3 dis+2 mut+2"),
                    Y.Sn("Çözemedin ama denemelerin sana bir şeyler öğretti.", "zek+1 str+2")),
                Y.SecSans("Arkadaşından kopya çek", 60, "sos:0.1",
                    Y.Sn("Kimse fark etmedi; ama vicdanın biraz kıpırdadı.", "dis-2 itb-1"),
                    Y.Sn("Öğretmen yakaladı ve herkesin önünde uyardı.", "itb-3 mut-3 dis-1"))));

            l.Add(Y.Karar("futbol_mac", HavuzTuru.Cocukluk, 8, 14,
                "Mahalle maçında kaleci çıkmadı; gözler sana çevrildi.|Halı saha maçında kaleci yaralandı, eldivenler sana uzatıldı.",
                Y.SecSans("Kaleye geç", 50, "sag:0.1,dis:0.1",
                    Y.Sn("Gol yememek için çabaladın; takım kazandı!", "sos+3 mut+4"),
                    Y.Sn("Beş gol yedin ama maçtan sonra herkes gülüştü.", "mut+1 sos+1")),
                Y.Sec("Hakemlik yap", "Düdüğü ciddiye aldın; kimse seni sevmedi ama herkes sana saygı duydu.", "itb+1 sos+1 str+1"),
                Y.Sec("Seyirci ol", "Kenarda tezahürat yaptın; sesin kısıldı ama moralin yerinde.", "mut+1")));

            l.Add(Y.Karar("yaz_tatilleri", HavuzTuru.Cocukluk, 7, 13,
                "Yaz tatili geldi; önünde uzun bir boşluk var.|Karneni aldın, yaz tatili resmen başladı.",
                Y.Sec("Köyde dedenle geçir", "Dedenle dere kenarında balık tuttun; hiç balık tutamadın ama çok şey öğrendin.", "sag+3 mut+3 dis+1"),
                Y.Sec("Yaz kursuna git", "Sabahları kursa gittin; akşamları pişmanlıktan çok yorgunluk vardı.", "zek+3 dis+2 mut-2"),
                Y.Sec("Sokakta arkadaşlarla oyna", "Bütün yaz oyun oynadın; dizlerin sıyrık, anıların taptaze.", "sos+4 mut+4 sag+1")));

            l.Add(Y.Karar("karne_gunu", HavuzTuru.Okul, 7, 17,
                "Karne günü geldi; zarfı açmadan önce derin bir nefes aldın.|Öğretmen karneleri dağıtırken kalbin yerinden çıkacaktı.",
                Y.SecSans("Heyecanla göster", 50, "zek:0.3,dis:0.3",
                    Y.Sn("Güzel notlar, dolu dolu övgüler! Akşam yemeği senin seçtiğin yerde.", "mut+4 itb+1 str-2"),
                    Y.Sn("Notlar beklediğin gibi değildi; annen 'seninle konuşacağız' dedi.", "mut-3 str+2")),
                Y.Sec("Eve yavaş yavaş git", "Yolu uzattın; sonunda karne yine de eve ulaştı.", "str+1 dis-1")));

            l.Add(Y.Karar("gece_korku", HavuzTuru.Cocukluk, 6, 10,
                "Gece odanda bir gölge gördün; kalbin hızla çarpmaya başladı.",
                Y.Sec("Annenin yanına koş", "Annenin yanına yattın; gölge odada kaldı, sen rahat uyudun.", "mut+1 str-1"),
                Y.Sec("Yorganın altına saklan", "Yorganın altında nefesini tuttun; sabaha kadar gölge bir daha görünmedi.", "str+1"),
                Y.SecSans("Işığı yak ve bak", 55, "dis:0.2",
                    Y.Sn("Askıdaki ceketmiş! Gülüp uyudun.", "mut+2 dis+1"),
                    Y.Sn("Hâlâ emin değilsin ama yorgunluktan uyudun.", "str+1"))).Bir().Agir(15));

            l.Add(Y.Karar("arkadas_agliyor", HavuzTuru.Okul, 6, 14,
                "Teneffüste bir arkadaşın ağlıyor; çevresinde kimse yok.|Sıra arkadaşın sessizce gözlerini siliyor.",
                Y.SecSans("Yanına git, sakinleştir", 60, "sos:0.3",
                    Y.Sn("Yanında oturdun, konuştun; yarım saat sonra birlikte gülüyordunuz.", "sos+3 itb+2 mut+2"),
                    Y.Sn("Ne diyeceğini bilemedin ama yanında durdun.", "sos+1")),
                Y.Sec("Öğretmene haber ver", "Öğretmen ilgilendi; sen de iyi bir iş yaptığını hissettin.", "itb+1"),
                Y.Sec("Görmezden gel", "Başka tarafa baktın ama içinde bir huzursuzluk kaldı.", "itb-2 mut-1")));

            l.Add(Y.Karar("okul_kavga", HavuzTuru.Okul, 8, 16,
                "Teneffüste biri sana kaba bir şaka yaptı; gerginlik yükseliyor.|Kantin kuyruğunda biri laf attı, herkes sana bakıyor.",
                Y.SecSans("Sakin kal ve uzaklaş", 55, "dis:0.3",
                    Y.Sn("İçinden yüze kadar saydın ve yürüdün. Çevrendekiler bunu fark etti.", "dis+2 itb+2 str-1"),
                    Y.Sn("İçinden bin kez saydın ama yine de bir laf yapıştırdın.", "str+2 itb-1")),
                Y.SecSans("Karşılık ver", 40, "sag:0.2,sos:0.1",
                    Y.Sn("Hakkını savundun ama müdür odasına çağrıldın.", "itb-3 sos+1 str+3"),
                    Y.Sn("İşler kötü gitti; hem üzüldün hem müdür odasına gittin.", "sag-4 itb-4 mut-3"))));

            l.Add(Y.Karar("okul_proje", HavuzTuru.Okul, 9, 17,
                "Okulda grup projesi verildi; ekip arkadaşların belli oldu.|Fen dersinde grup ödevi: kim ne yapacak, kimse bilmiyor.",
                Y.SecSans("Liderliği üstlen", 45, "sos:0.2,zek:0.2",
                    Y.Sn("Ekibi çalıştırdın; proje tam zamanında teslim edildi.", "itb+2 sos+3 zek+2"),
                    Y.Sn("Grup biraz dağıldı ama projeyi teslim ettiniz.", "str+3 sos+1")),
                Y.Sec("Sessizce kendi işini yap", "Payına düşeni eksiksiz yaptın; kimse şikâyet etmedi.", "zek+1 dis+1"),
                Y.Sec("Başkalarına bırak", "Proje teslim edildi ama senin katkın pek anılmadı.", "dis-2 itb-1")));

            l.Add(Y.Karar("dogum_gunu", HavuzTuru.Aile, 6, 40,
                "Doğum günün geldi; pastada mumlar bir yaş daha büyüdü.|Bugün doğum günün! Telefonuna mesajlar yağıyor.",
                Y.Sec("Arkadaşlarla kutla", "Pasta, müzik ve fazla gürültü; komşular bile gülümsedi.", "mut+4 sos+3 para-500"),
                Y.Sec("Ailenle kutla", "Sıcak bir sofra, eski hikâyeler ve fazlasıyla tatlı.", "mut+4 sos+1"),
                Y.Sec("Hiç kutlama", "Sakin bir gün geçirdin; gün bittiğinde fazla bir şey hissetmedin.", "mut-1")).Agir(8));
        }
    }
}
