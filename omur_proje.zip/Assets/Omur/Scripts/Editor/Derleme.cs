#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Omur.EditorAraclari
{
    /// <summary>Bulutta (GitHub Actions) Android APK üretir: sahneyi kendisi kurar, ayarları kodla yapar.</summary>
    public static class Derleme
    {
        public static void AndroidApk()
        {
            Directory.CreateDirectory("Assets/Scenes");
            var sahne = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            EditorSceneManager.SaveScene(sahne, "Assets/Scenes/Ana.unity");
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/Ana.unity", true) };

            PlayerSettings.companyName = "Omur";
            PlayerSettings.productName = "Ömür";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.omur.hayat");
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            EditorUserBuildSettings.buildAppBundle = false;

            Directory.CreateDirectory("build/Android");
            BuildPlayerOptions secenekler = new BuildPlayerOptions();
            secenekler.scenes = new[] { "Assets/Scenes/Ana.unity" };
            secenekler.locationPathName = "build/Android/omur.apk";
            secenekler.target = BuildTarget.Android;
            secenekler.options = BuildOptions.None;
            var rapor = BuildPipeline.BuildPlayer(secenekler);
            if (rapor.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded)
            {
                EditorApplication.Exit(1);
            }
        }
    }
}
#endif
