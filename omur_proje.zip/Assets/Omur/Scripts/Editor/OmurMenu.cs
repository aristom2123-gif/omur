#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace Omur.EditorAraclari
{
    /// <summary>Unity editöründe denge testi ve veri doğrulaması için menü komutları.</summary>
    public static class OmurMenu
    {
        [MenuItem("Ömür/Veriyi doğrula")]
        private static void VeriyiDogrula()
        {
            System.Collections.Generic.List<string> sorunlar = OlayHavuzu.Dogrula();
            Debug.Log("[Ömür] Olay sayısı: " + OlayHavuzu.Tum.Count + ", sorun: " + sorunlar.Count);
            for (int i = 0; i < sorunlar.Count; i++) Debug.LogWarning("[Ömür veri] " + sorunlar[i]);
        }

        [MenuItem("Ömür/Simülasyon: 1000 hayat (rastgele seçimler)")]
        private static void Simulasyon1000()
        {
            Debug.Log(Simulasyon.Calistir(1000, 0));
        }

        [MenuItem("Ömür/Simülasyon: 1000 hayat (en yüksek şans)")]
        private static void Simulasyon1000Sans()
        {
            Debug.Log(Simulasyon.Calistir(1000, 1));
        }

        [MenuItem("Ömür/Kayıtların klasörünü göster")]
        private static void KayitKlasoru()
        {
            EditorUtility.RevealInFinder(Application.persistentDataPath);
        }
    }
}
#endif
